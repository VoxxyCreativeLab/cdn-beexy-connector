<?php
/**
 * Plugin Name:       Beexy Connector
 * Plugin URI:        https://beexy.io/connector
 * Description:       Same-origin reverse proxy that forwards a first-party path to the client's server-side GTM backend and rewrites the Set-Cookie Domain, so the Beexy _bx_* cookie set is written first-party and survives Safari ITP's 7-day cap.
 * Version:           0.2.1
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Voxxy Creative Lab
 * Author URI:        https://voxxycreativelab.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       beexy-connector
 * Domain Path:       /languages
 * Update URI:        https://updates.beexy.io/connector
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'BEEXY_CONNECTOR_PLUGIN_FILE' ) ) {
	define( 'BEEXY_CONNECTOR_PLUGIN_FILE', __FILE__ );
}

require_once __DIR__ . '/bootstrap.php';
