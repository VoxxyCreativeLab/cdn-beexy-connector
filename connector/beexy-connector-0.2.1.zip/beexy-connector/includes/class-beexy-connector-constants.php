<?php
/**
 * Central plugin constants + config-key names.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Plugin-wide constants.
 */
class Beexy_Connector_Constants {

	const VERSION     = '0.2.1';
	const SLUG        = 'beexy-connector';
	const TEXT_DOMAIN = 'beexy-connector';
	const CAPABILITY  = 'manage_options';

	/**
	 * The private update-metadata endpoint (overridable by the
	 * BEEXY_CONNECTOR_UPDATE_URL constant for per-environment channels).
	 */
	const DEFAULT_UPDATE_URL = 'https://updates.beexy.io/connector/info.json';

	/**
	 * The stable License Gate endpoint (overridable by the BEEXY_CONNECTOR_LICENSE_URL
	 * constant, used to point at the raw Supabase ref for testing before the
	 * license.beexy.io custom domain is stood up; 0017 contract §4). The Connector is
	 * a server-side caller, so it POSTs { key } and sends its own domain in the
	 * X-Beexy-Domain header (0017 contract §4/§5), never a domain in the body.
	 */
	const DEFAULT_LICENSE_URL = 'https://license.beexy.io/functions/v1/validate-license';

	/** License enforcement modes (0009 Receiver precedent): Off / Watch / Block. */
	const LICENSE_MODE_OFF   = 'off';
	const LICENSE_MODE_WATCH = 'watch';
	const LICENSE_MODE_BLOCK = 'block';

	/**
	 * Verdict cache TTL in seconds (12h). The verdict is cached regardless of sign
	 * and refreshed OFF the hot beacon path (daily cron + admin load); on any
	 * no-verdict response the last cached-good is kept, bounded by this TTL
	 * (0017 contract §4/§7).
	 */
	const LICENSE_CACHE_TTL = 43200;

	/** Cron hook that refreshes the license verdict off the hot beacon path. */
	const LICENSE_CRON_HOOK = 'beexy_connector_license_refresh';

	/**
	 * The wp-config / PHP constant names that carry the SSRF-critical config.
	 * These resolve from constants ONLY (never a web-editable option).
	 *
	 * @var array<string,string>
	 */
	public static $critical_constants = array(
		'upstream_base'      => 'BEEXY_CONNECTOR_UPSTREAM_BASE',
		'upstream_allowlist' => 'BEEXY_CONNECTOR_UPSTREAM_ALLOWLIST',
		'cookie_domain'      => 'BEEXY_CONNECTOR_COOKIE_DOMAIN',
		'proxy_path'         => 'BEEXY_CONNECTOR_PROXY_PATH',
		'serving_host'       => 'BEEXY_CONNECTOR_SERVING_HOST',
	);

	/**
	 * Optional wp-config / PHP constant names for the license layer. These are NOT
	 * SSRF-critical, so an admin option is the default path; a defined constant WINS
	 * and locks the value, the multi-domain zero-touch deploy path, where one
	 * account-scoped key is set once (e.g. via a deploy script) across many installs.
	 *
	 * @var array<string,string>
	 */
	public static $license_constants = array(
		'license_key'  => 'BEEXY_CONNECTOR_LICENSE_KEY',
		'license_mode' => 'BEEXY_CONNECTOR_LICENSE_MODE',
		'license_url'  => 'BEEXY_CONNECTOR_LICENSE_URL',
	);
}
