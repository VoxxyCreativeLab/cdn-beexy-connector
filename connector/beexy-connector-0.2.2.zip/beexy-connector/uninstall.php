<?php
/**
 * Uninstall cleanup.
 *
 * The proxy is configured by wp-config constants (not options), so there is very
 * little to remove — only the diagnostic version marker.
 *
 * @package Beexy_Connector
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'beexy_connector_version' );
delete_option( 'beexy_connector_allowed_methods' );
delete_option( 'beexy_connector_connect_timeout_ms' );
delete_option( 'beexy_connector_total_timeout_ms' );
delete_option( 'beexy_connector_max_bytes' );
