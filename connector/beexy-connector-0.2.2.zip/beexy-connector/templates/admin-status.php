<?php
/**
 * Admin settings + status view. Included by Beexy_Connector_Admin::render().
 *
 * The form posts to options.php via the Settings API (capability + nonce enforced
 * by core). Every value printed here is escaped — CVE-2024-8712 in the Stape plugin
 * was reflected XSS, so a reverse-proxy settings screen must escape all output.
 *
 * The license key + Off/Watch/Block mode (F3) render in the same settings form, and
 * the License status row shows the cached verdict.
 *
 * Built per: docs/superpowers/plans/2026-10-10-connector-f3.md
 *
 * @package Beexy_Connector
 * @var Beexy_Connector_Proxy_Config|null $config
 */

defined( 'ABSPATH' ) || exit;

$beexy_connector_cfg        = ( isset( $config ) && $config instanceof Beexy_Connector_Proxy_Config ) ? $config : null;
$beexy_connector_ready      = null !== $beexy_connector_cfg;
$beexy_connector_locked     = Beexy_Connector_Admin::is_locked();
$beexy_connector_sgtm_url   = (string) get_option( Beexy_Connector_Admin::OPT_SGTM_URL, '' );
$beexy_connector_pixel      = (string) get_option( Beexy_Connector_Admin::OPT_PIXEL_PATH, '' );
$beexy_connector_lic        = Beexy_Connector_License::get_instance();
$beexy_connector_lic_mode   = $beexy_connector_lic->mode();
$beexy_connector_lic_key    = (string) get_option( Beexy_Connector_License::OPT_KEY, '' );
$beexy_connector_lic_locked = $beexy_connector_lic->key_is_locked();
$beexy_connector_lic_vdict  = $beexy_connector_lic->current_verdict();
if ( '' === $beexy_connector_lic_key && ! $beexy_connector_lic_locked ) {
	$beexy_connector_lic_status = __( 'No key set. The Connector runs unlicensed in this version.', 'beexy-connector' );
} elseif ( is_array( $beexy_connector_lic_vdict ) && array_key_exists( 'valid', $beexy_connector_lic_vdict ) ) {
	if ( false === $beexy_connector_lic_vdict['valid'] ) {
		$beexy_connector_lic_status = __( 'Not licensed for this domain.', 'beexy-connector' );
	} elseif ( ! empty( $beexy_connector_lic_vdict['is_wildcard'] ) ) {
		$beexy_connector_lic_status = __( 'Not licensed: this is an all-domains (Consent-only) key; the Connector needs a domain-bound key.', 'beexy-connector' );
	} else {
		$beexy_connector_lic_status = __( 'Licensed for this domain.', 'beexy-connector' );
	}
} else {
	$beexy_connector_lic_status = __( 'License not yet confirmed (the license server was not reachable; serving continues).', 'beexy-connector' );
}
$beexy_connector_update = defined( 'BEEXY_CONNECTOR_UPDATE_URL' ) ? (string) BEEXY_CONNECTOR_UPDATE_URL : Beexy_Connector_Constants::DEFAULT_UPDATE_URL;
$beexy_connector_verify = get_transient( 'beexy_connector_verify_result' );
?>
<div class="wrap">
	<h1><?php esc_html_e( 'Beexy Connector', 'beexy-connector' ); ?></h1>
	<p style="max-width:820px;">
		<?php esc_html_e( 'Serves your Beexy tracking through your own domain so first-party cookies survive Safari. Paste your Beexy sGTM URL below — that is the only thing you need.', 'beexy-connector' ); ?>
	</p>

	<?php settings_errors(); // Save confirmation + sanitize-callback validation errors (not auto-rendered on a custom options page). ?>

	<?php if ( $beexy_connector_locked ) : ?>
		<div class="notice notice-info inline"><p>
			<strong><?php esc_html_e( 'Locked by wp-config.', 'beexy-connector' ); ?></strong>
			<?php esc_html_e( 'This site is configured with BEEXY_CONNECTOR_* constants, which override these settings. Remove them to edit the connection here.', 'beexy-connector' ); ?>
				<?php esc_html_e( 'On a locked install the license key is set with the BEEXY_CONNECTOR_LICENSE_KEY constant (and the mode with BEEXY_CONNECTOR_LICENSE_MODE); the License status below still updates.', 'beexy-connector' ); ?>
		</p></div>
	<?php else : ?>
		<form method="post" action="options.php">
			<?php settings_fields( Beexy_Connector_Admin::OPTION_GROUP ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">
						<label for="beexy_connector_sgtm_url"><?php esc_html_e( 'Your Beexy sGTM URL', 'beexy-connector' ); ?></label>
					</th>
					<td>
						<input name="<?php echo esc_attr( Beexy_Connector_Admin::OPT_SGTM_URL ); ?>" id="beexy_connector_sgtm_url" type="url" class="regular-text code" placeholder="https://sst.yoursite.com/your-random-path" value="<?php echo esc_attr( $beexy_connector_sgtm_url ); ?>" />
						<p class="description"><?php esc_html_e( 'Paste the URL from your Beexy / server-side GTM setup. Required — everything else is derived from it and your site address.', 'beexy-connector' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="beexy_connector_pixel_path"><?php esc_html_e( 'Pixel event path (optional)', 'beexy-connector' ); ?></label>
					</th>
					<td>
						<input name="<?php echo esc_attr( Beexy_Connector_Admin::OPT_PIXEL_PATH ); ?>" id="beexy_connector_pixel_path" type="text" class="regular-text code" placeholder="/api-experience" value="<?php echo esc_attr( $beexy_connector_pixel ); ?>" />
						<p class="description"><?php esc_html_e( 'Only if your Beexy Pixel events use a different path on the same server. Leave blank otherwise.', 'beexy-connector' ); ?></p>
					</td>
				</tr>
			</table>
			<table class="form-table" role="presentation">
					<tr>
						<th scope="row">
							<label for="beexy_connector_license_key"><?php esc_html_e( 'License key (optional)', 'beexy-connector' ); ?></label>
						</th>
						<td>
							<input name="<?php echo esc_attr( Beexy_Connector_License::OPT_KEY ); ?>" id="beexy_connector_license_key" type="text" class="regular-text code" placeholder="bx_live_..." value="<?php echo esc_attr( $beexy_connector_lic_key ); ?>"<?php disabled( $beexy_connector_lic_locked ); ?> />
							<p class="description">
								<?php esc_html_e( 'Your Beexy account license key. Leave blank to run unlicensed (this version works without one).', 'beexy-connector' ); ?>
								<?php
								if ( $beexy_connector_lic_locked ) {
									echo ' ';
									esc_html_e( 'Set by a wp-config constant.', 'beexy-connector' );
								}
								?>
							</p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="beexy_connector_license_mode"><?php esc_html_e( 'License enforcement', 'beexy-connector' ); ?></label>
						</th>
						<td>
							<select name="<?php echo esc_attr( Beexy_Connector_License::OPT_MODE ); ?>" id="beexy_connector_license_mode"<?php disabled( $beexy_connector_lic->mode_is_locked() ); ?>>
								<option value="off"<?php selected( $beexy_connector_lic_mode, 'off' ); ?>><?php esc_html_e( 'Off (ignore licensing)', 'beexy-connector' ); ?></option>
								<option value="watch"<?php selected( $beexy_connector_lic_mode, 'watch' ); ?>><?php esc_html_e( 'Watch (check and show, change nothing)', 'beexy-connector' ); ?></option>
								<option value="block"<?php selected( $beexy_connector_lic_mode, 'block' ); ?>><?php esc_html_e( 'Block (stop serving on an unlicensed domain)', 'beexy-connector' ); ?></option>
							</select>
							<p class="description"><?php esc_html_e( 'Watch is recommended: it shows the result without changing anything. Block stops the same-origin proxy on a domain the license server rejects.', 'beexy-connector' ); ?></p>
						</td>
					</tr>
				</table>
				<?php submit_button( __( 'Save & verify', 'beexy-connector' ) ); ?>
		</form>
	<?php endif; ?>

	<h2><?php esc_html_e( 'Status', 'beexy-connector' ); ?></h2>
	<?php if ( is_array( $beexy_connector_verify ) ) : ?>
		<div class="notice notice-<?php echo esc_attr( Beexy_Connector_Admin::probe_severity( ! empty( $beexy_connector_verify['reachable'] ), ! empty( $beexy_connector_verify['bx_cookie'] ) ) ); ?> inline"><p>
			<?php echo esc_html( isset( $beexy_connector_verify['message'] ) ? (string) $beexy_connector_verify['message'] : '' ); ?>
		</p></div>
	<?php endif; ?>
	<?php if ( ! $beexy_connector_ready ) : ?>
		<div class="notice notice-warning inline"><p>
			<strong><?php esc_html_e( 'Not connected yet.', 'beexy-connector' ); ?></strong>
			<?php esc_html_e( 'Paste your Beexy sGTM URL above and save.', 'beexy-connector' ); ?>
		</p></div>
	<?php else : ?>
		<table class="widefat striped" style="max-width:820px;">
			<tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Forwarding path(s)', 'beexy-connector' ); ?></th>
					<td><code><?php echo esc_html( implode( ', ', $beexy_connector_cfg->proxy_paths() ) ); ?></code> &rarr; <code><?php echo esc_html( $beexy_connector_cfg->upstream_base() ); ?></code></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Cookie Domain (eTLD+1)', 'beexy-connector' ); ?></th>
					<td><code><?php echo esc_html( $beexy_connector_cfg->cookie_domain() ); ?></code></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Serving host (auto)', 'beexy-connector' ); ?></th>
					<td><code><?php echo esc_html( $beexy_connector_cfg->serving_host() ); ?></code></td>
				</tr>
			</tbody>
		</table>
		<?php $beexy_connector_targets = Beexy_Connector_Admin::activation_targets( $beexy_connector_cfg->proxy_paths() ); ?>
		<div class="notice notice-info inline" style="max-width:820px;">
			<p><strong><?php esc_html_e( 'Activate same-origin durability (optional)', 'beexy-connector' ); ?></strong></p>
			<p><?php esc_html_e( 'First-party cookies survive Safari only when tracking is served from this site\'s own host. To activate, point your Beexy setup here:', 'beexy-connector' ); ?></p>
			<ul style="list-style:disc;margin:0 0 8px 20px;">
				<li>
					<?php esc_html_e( 'Beexy loader endpoint', 'beexy-connector' ); ?> &rarr;
					<code><?php echo esc_html( $beexy_connector_targets['loader'] ); ?></code>
					<em><?php esc_html_e( '(relative — this plugin serves it)', 'beexy-connector' ); ?></em>
				</li>
				<?php if ( '' !== $beexy_connector_targets['pixel'] ) : ?>
					<li>
						<?php esc_html_e( 'Beexy Pixel — Data Transmitter Server URL', 'beexy-connector' ); ?> &rarr;
						<code><?php echo esc_html( $beexy_connector_cfg->serving_host() ); ?></code>
						<?php esc_html_e( 'endpoint path', 'beexy-connector' ); ?>
						<code><?php echo esc_html( $beexy_connector_targets['pixel'] ); ?></code>
					</li>
				<?php endif; ?>
			</ul>
			<p><?php esc_html_e( 'Optional — without it, tracking still works through your sGTM host directly; Safari just caps those cookies at 7 days (the Beexy loader\'s refresh-on-visit softens it).', 'beexy-connector' ); ?></p>
			<p>
				<strong><?php esc_html_e( 'Verify in a browser:', 'beexy-connector' ); ?></strong>
				<?php esc_html_e( 'the loader request\'s Remote Address matches the page\'s, and _bx_uid keeps its full ~390-day expiry past 7 days on Safari.', 'beexy-connector' ); ?>
			</p>
		</div>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:10px;">
			<input type="hidden" name="action" value="beexy_connector_verify" />
			<?php wp_nonce_field( 'beexy_connector_verify' ); ?>
			<?php submit_button( __( 'Verify connection', 'beexy-connector' ), 'secondary', 'beexy_connector_verify_submit', false ); ?>
		</form>
	<?php endif; ?>

	<h2><?php esc_html_e( 'Family status', 'beexy-connector' ); ?></h2>
	<table class="widefat striped" style="max-width:820px;">
		<tbody>
			<tr>
				<th scope="row"><?php esc_html_e( 'License', 'beexy-connector' ); ?></th>
				<td>
						<?php echo esc_html( $beexy_connector_lic_status ); ?>
						<br /><span class="description">
							<?php
							/* translators: %s: license enforcement mode (off, watch, or block). */
							echo esc_html( sprintf( __( 'Enforcement mode: %s', 'beexy-connector' ), $beexy_connector_lic_mode ) );
							?>
						</span>
					</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Update channel', 'beexy-connector' ); ?></th>
				<td><code><?php echo esc_html( $beexy_connector_update ); ?></code></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Version', 'beexy-connector' ); ?></th>
				<td><code><?php echo esc_html( Beexy_Connector_Constants::VERSION ); ?></code></td>
			</tr>
		</tbody>
	</table>
</div>
