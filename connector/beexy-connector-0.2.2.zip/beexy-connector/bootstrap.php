<?php
/**
 * Bootstrap: register the house autoloader, run early interception, wire hooks.
 *
 * Required by the main plugin file (and, if installed, by the mu-loader shim).
 * Idempotent via require_once + the interceptor's own guard.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * House autoloader:
 *   Beexy_Connector_Foo_Bar        -> includes/class-beexy-connector-foo-bar.php
 *   Beexy_Connector_Foo_Interface  -> includes/interface-beexy-connector-foo.php
 *   Beexy_Connector_Singleton (trait) resolves via the class- filename too.
 */
spl_autoload_register(
	static function ( $class_name ) {
		if ( 0 !== strpos( $class_name, 'Beexy_Connector' ) ) {
			return;
		}
		$slug = strtolower( str_replace( '_', '-', $class_name ) );
		if ( '-interface' === substr( $slug, -10 ) ) {
			$file = 'interface-' . substr( $slug, 0, -10 ) . '.php';
		} else {
			$file = 'class-' . $slug . '.php';
		}
		$path = dirname( BEEXY_CONNECTOR_PLUGIN_FILE ) . '/includes/' . $file;
		if ( is_file( $path ) ) {
			require_once $path;
		}
	}
);

// Early interception — runs at plugin-load, before full WP boot where possible.
// On a matching proxy request this emits and exits; otherwise it returns cheaply.
Beexy_Connector_Interceptor::maybe_handle();

// Non-hot-path wiring (only reached for non-proxy requests).
register_activation_hook( BEEXY_CONNECTOR_PLUGIN_FILE, array( 'Beexy_Connector_Activator', 'activate' ) );
register_deactivation_hook( BEEXY_CONNECTOR_PLUGIN_FILE, array( 'Beexy_Connector_Activator', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'Beexy_Connector_I18n', 'load' ) );
add_action( 'init', array( 'Beexy_Connector_Updater', 'init' ) );

// Daily off-hot-path license re-check (F3). Registered here so the wp-cron request
// (not a proxy hit) wires it; the callback is a static entry so the gate is never
// instantiated on the hot beacon path.
add_action( Beexy_Connector_Constants::LICENSE_CRON_HOOK, array( 'Beexy_Connector_License', 'cron_refresh' ) );
// Ensure the daily event exists even after an auto-update (register_activation_hook
// does not run on update, and this plugin auto-updates). Guarded + idempotent; runs
// on init only for non-proxy requests (the interceptor exits before init on a hit).
add_action( 'init', array( 'Beexy_Connector_License', 'ensure_scheduled' ) );

if ( is_admin() ) {
	Beexy_Connector_Admin::init();
}
