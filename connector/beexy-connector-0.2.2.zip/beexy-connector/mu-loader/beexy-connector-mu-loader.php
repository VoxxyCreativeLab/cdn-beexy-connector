<?php
/**
 * Beexy Connector — OPTIONAL mu-plugin loader shim.
 *
 * INACTIVE BY DEFAULT. Copy this single file to wp-content/mu-plugins/ ONLY when a
 * web-server / page cache (e.g. LiteSpeed "cache before PHP") serves the proxy path
 * before regular plugins load. mu-plugins run before regular plugins and most cache
 * plugins' hooks, so the interceptor gets an earlier shot. It simply loads the real,
 * updatable plugin's bootstrap (no logic is duplicated here).
 *
 * The proxy path must ALSO be excluded from any full-page cache and is always
 * emitted with Cache-Control: no-store.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

$beexy_connector_main      = WP_PLUGIN_DIR . '/beexy-connector/beexy-connector.php';
$beexy_connector_bootstrap = WP_PLUGIN_DIR . '/beexy-connector/bootstrap.php';

if ( is_file( $beexy_connector_main ) && is_file( $beexy_connector_bootstrap ) ) {
	if ( ! defined( 'BEEXY_CONNECTOR_PLUGIN_FILE' ) ) {
		define( 'BEEXY_CONNECTOR_PLUGIN_FILE', $beexy_connector_main );
	}
	require_once $beexy_connector_bootstrap;
}
