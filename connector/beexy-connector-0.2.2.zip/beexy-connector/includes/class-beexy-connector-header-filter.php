<?php
/**
 * Filters upstream response headers before they are re-emitted to the browser.
 *
 * Pure: no WordPress, no I/O. Contract C-RES-1..6 + C-SAN-1:
 *
 *  - strips vendor + hop-by-hop headers,
 *  - forces `Cache-Control: no-store` (dropping upstream cache directives),
 *  - force-sets a single `X-Content-Type-Options: nosniff` (C-RES-5),
 *  - drops redirect-driving headers (`Location` / `Refresh`) on the beacon path (C-RES-6),
 *  - preserves the page's own security headers + Content-Type / Content-Encoding,
 *  - drops Set-Cookie (rewritten separately by Beexy_Connector_Cookie_Rewriter),
 *  - throws on any CR/LF in a header line (anti response-splitting).
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Response header filter.
 */
class Beexy_Connector_Header_Filter {

	/**
	 * The canonical headers force-set on EVERY proxied response — the single source
	 * of truth, also consumed by the fail-open Beexy_Connector_Response_Factory so
	 * the invariant holds on the fail-open path too (C-RES-2, C-RES-5). Each name is
	 * also stripped from the upstream headers (see $strip_exact) so exactly one
	 * canonical copy is emitted.
	 *
	 * @var string[]
	 */
	const FORCED_HEADERS = array(
		'Cache-Control: no-store',
		'X-Content-Type-Options: nosniff',
	);

	/**
	 * Header names (lower-case) removed outright: hop-by-hop, vendor, and the
	 * cache directives we override with a forced no-store.
	 *
	 * @var string[]
	 */
	private static $strip_exact = array(
		// Hop-by-hop (RFC 7230 6.1).
		'connection',
		'keep-alive',
		'proxy-authenticate',
		'proxy-authorization',
		'te',
		'trailer',
		'transfer-encoding',
		'upgrade',
		// Vendor / infrastructure fingerprints.
		'server',
		'x-powered-by',
		'via',
		'x-served-by',
		'x-timer',
		'x-litespeed-cache',
		'x-turbo-charged-by',
		'x-nginx-cache',
		'x-redirect-by',
		// Cache directives — replaced by the forced no-store (FORCED_HEADERS).
		'cache-control',
		'expires',
		'pragma',
		'age',
		// Redirect-driving headers dropped on the beacon path (C-RES-6). The proxy
		// never legitimately redirects the browser, so a relayed upstream Location or
		// Refresh would become an open redirect on the client's first-party origin.
		'location',
		'refresh',
		// Replaced by the forced nosniff (FORCED_HEADERS, C-RES-5).
		'x-content-type-options',
	);

	/**
	 * Header name prefixes (lower-case) removed outright.
	 *
	 * @var string[]
	 */
	private static $strip_prefix = array(
		'x-cache',
		'cf-',
	);

	/**
	 * Filter the response header lines. Returns the non-Set-Cookie headers with the
	 * canonical FORCED_HEADERS appended.
	 *
	 * @param string[] $header_lines Raw upstream response header lines ("Name: value").
	 * @return string[]
	 * @throws Beexy_Connector_Http_Exception If any line contains CR or LF.
	 */
	public function filter( array $header_lines ) {
		$out = array();

		foreach ( $header_lines as $line ) {
			$line = (string) $line;
			if ( '' === $line ) {
				continue;
			}
			if ( preg_match( '/[\r\n]/', $line ) ) {
				throw new Beexy_Connector_Http_Exception( 'CR/LF in a response header line (response-splitting attempt)' );
			}
			$colon = strpos( $line, ':' );
			if ( false === $colon ) {
				continue; // Malformed header line — drop it.
			}
			$name = strtolower( trim( substr( $line, 0, $colon ) ) );
			if ( 'set-cookie' === $name ) {
				continue; // Handled by the cookie rewriter.
			}
			if ( $this->is_stripped( $name ) ) {
				continue;
			}
			$out[] = $line;
		}

		// Force the canonical response headers (single source of truth; the upstream
		// copies were stripped above, so exactly one of each is emitted).
		foreach ( self::FORCED_HEADERS as $forced ) {
			$out[] = $forced;
		}

		return $out;
	}

	/**
	 * Should a header name be stripped?
	 *
	 * @param string $name Lower-case header name.
	 * @return bool
	 */
	private function is_stripped( $name ) {
		if ( in_array( $name, self::$strip_exact, true ) ) {
			return true;
		}
		foreach ( self::$strip_prefix as $prefix ) {
			if ( 0 === strpos( $name, $prefix ) ) {
				return true;
			}
		}
		return false;
	}
}
