<?php
/**
 * Upstream response (value object).
 *
 * Pure. `header_lines` is the RAW, ordered list captured from the upstream, with
 * duplicate Set-Cookie lines preserved as separate entries (the curl client uses
 * CURLOPT_HEADERFUNCTION so cookies are never collapsed).
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Immutable upstream response.
 */
class Beexy_Connector_Upstream_Response {

	/** @var int */
	private $status;
	/** @var string[] */
	private $header_lines;
	/** @var string */
	private $body;

	/**
	 * @param int      $status       HTTP status code.
	 * @param string[] $header_lines Raw response header lines, ordered, duplicates kept.
	 * @param string   $body         Raw response body bytes.
	 */
	public function __construct( $status, array $header_lines, $body ) {
		$this->status       = (int) $status;
		$this->header_lines = $header_lines;
		$this->body         = (string) $body;
	}

	/** @return int */
	public function status() {
		return $this->status;
	}
	/** @return string[] */
	public function header_lines() {
		return $this->header_lines;
	}
	/** @return string */
	public function body() {
		return $this->body;
	}
}
