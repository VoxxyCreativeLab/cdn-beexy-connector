<?php
/**
 * Thrown when the proxy configuration is malformed.
 *
 * A configuration failure MUST prevent the plugin from ever becoming an open
 * proxy (contract C-CFG-1): callers either decline to intercept or fail open.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Invalid proxy configuration.
 */
class Beexy_Connector_Config_Exception extends RuntimeException {
}
