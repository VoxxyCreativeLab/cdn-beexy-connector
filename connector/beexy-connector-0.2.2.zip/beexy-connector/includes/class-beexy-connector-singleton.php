<?php
/**
 * Singleton trait (house pattern, mirrors the family GTM plugin).
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Provides a shared instance + a test reset hook.
 */
trait Beexy_Connector_Singleton {

	/** @var static|null */
	private static $instance = null;

	/**
	 * Shared instance.
	 *
	 * @return static
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}
		return static::$instance;
	}

	/**
	 * Reset the shared instance (tests only).
	 *
	 * @return void
	 */
	public static function reset_instance() {
		static::$instance = null;
	}

	/**
	 * Private constructor — use get_instance().
	 */
	private function __construct() {
		if ( method_exists( $this, 'init' ) ) {
			$this->init();
		}
	}
}
