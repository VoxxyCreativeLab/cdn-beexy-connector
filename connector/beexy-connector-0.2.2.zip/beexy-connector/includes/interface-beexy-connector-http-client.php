<?php
/**
 * HTTP client seam — the single injection point that keeps the core network-free.
 *
 * The real implementation (Beexy_Connector_Curl_Http_Client) is the only place
 * curl_* lives; tests inject a fake. Implementations MUST NOT re-derive the host:
 * the target URL and DNS pin are fixed on the Upstream_Request by the SSRF guard.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Sends a pre-built upstream request.
 */
interface Beexy_Connector_Http_Client_Interface {

	/**
	 * Send the request and return the response.
	 *
	 * @param Beexy_Connector_Upstream_Request $request Fully-built, validated request.
	 * @return Beexy_Connector_Upstream_Response
	 * @throws Beexy_Connector_Http_Exception On any transport failure or timeout.
	 */
	public function send( Beexy_Connector_Upstream_Request $request );
}
