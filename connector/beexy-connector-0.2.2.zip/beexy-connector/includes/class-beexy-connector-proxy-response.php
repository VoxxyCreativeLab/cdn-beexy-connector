<?php
/**
 * Outbound client response (value object).
 *
 * Pure: the response the core hands back to the WP edge
 * (Beexy_Connector_Response_Emitter), which is the only place `header()` and
 * output happen. `header_lines` is an ordered list; duplicate Set-Cookie lines
 * are preserved as separate entries (never collapsed).
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Immutable client response.
 */
class Beexy_Connector_Proxy_Response {

	/** @var int */
	private $status;
	/** @var string[] */
	private $header_lines;
	/** @var string */
	private $body;

	/**
	 * @param int      $status       HTTP status code.
	 * @param string[] $header_lines Response header lines ("Name: value"), ordered, duplicates kept.
	 * @param string   $body         Response body bytes.
	 */
	public function __construct( $status, array $header_lines, $body ) {
		$this->status       = (int) $status;
		$this->header_lines = $header_lines;
		$this->body         = (string) $body;
	}

	/** @return int */
	public function status() {
		return $this->status;
	}
	/** @return string[] */
	public function header_lines() {
		return $this->header_lines;
	}
	/** @return string */
	public function body() {
		return $this->body;
	}
}
