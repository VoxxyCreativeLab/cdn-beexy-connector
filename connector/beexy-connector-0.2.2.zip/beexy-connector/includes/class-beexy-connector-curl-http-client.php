<?php
/**
 * Real HTTP client (native cURL) — the network boundary.
 *
 * The only place curl_* lives. Native cURL is a deliberate requirement: the SSRF
 * defence needs CURLOPT_RESOLVE pinning and protocol restriction, which the WP HTTP
 * API cannot express (and which is not loaded at the early interception hook). It:
 *
 *  - pins the connection to the guard's validated IP (CURLOPT_RESOLVE) — DNS-rebinding,
 *  - allows HTTPS only, disables redirects, applies short timeouts + a size cap,
 *  - captures each response header individually (CURLOPT_HEADERFUNCTION) so multiple
 *    Set-Cookie lines are never collapsed, and caps header volume so a flooding
 *    upstream cannot exhaust memory.
 *
 * Not unit-tested (it is the seam boundary); exercised live in stage 04.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * cURL-backed HTTP client.
 */
class Beexy_Connector_Curl_Http_Client implements Beexy_Connector_Http_Client_Interface {

	/**
	 * @param Beexy_Connector_Upstream_Request $request Fully-built request.
	 * @return Beexy_Connector_Upstream_Response
	 * @throws Beexy_Connector_Http_Exception On any transport failure.
	 */
	public function send( Beexy_Connector_Upstream_Request $request ) {
		if ( ! function_exists( 'curl_init' ) ) {
			throw new Beexy_Connector_Http_Exception( 'cURL is not available' );
		}

		$header_lines = array();
		$header_bytes = 0;
		$body         = '';
		$max_bytes    = $request->max_bytes();
		$pin          = $request->resolve_pin();

		$handle = curl_init();

		$options = array(
			CURLOPT_URL               => $request->url(),
			CURLOPT_CUSTOMREQUEST     => $request->method(),
			CURLOPT_HTTPHEADER        => $request->headers(),
			CURLOPT_RETURNTRANSFER    => false,
			CURLOPT_HEADER            => false,
			CURLOPT_FOLLOWLOCATION    => false,
			CURLOPT_PROTOCOLS         => CURLPROTO_HTTPS,
			CURLOPT_REDIR_PROTOCOLS   => CURLPROTO_HTTPS,
			CURLOPT_CONNECTTIMEOUT_MS => $request->connect_timeout_ms(),
			CURLOPT_TIMEOUT_MS        => $request->total_timeout_ms(),
			CURLOPT_SSL_VERIFYPEER    => true,
			CURLOPT_SSL_VERIFYHOST    => 2,
			CURLOPT_HEADERFUNCTION    => static function ( $curl_handle, $line ) use ( &$header_lines, &$header_bytes ) {
				$trimmed       = trim( (string) $line, "\r\n" );
				$header_bytes += strlen( $trimmed );
				// Bound memory: a legitimate beacon response never carries thousands of
				// header lines. Abort (-> CURLE_WRITE_ERROR -> fail open) rather than let a
				// flooding / compromised upstream exhaust memory — an uncatchable OOM would
				// escape the proxy's fail-open boundary.
				if ( count( $header_lines ) >= 200 || $header_bytes > 65536 ) {
					return 0;
				}
				if ( '' !== $trimmed && false !== strpos( $trimmed, ':' ) ) {
					$header_lines[] = $trimmed;
				}
				return strlen( (string) $line );
			},
			CURLOPT_WRITEFUNCTION     => static function ( $curl_handle, $data ) use ( &$body, $max_bytes ) {
				$chunk = (string) $data;
				// Check the projected length BEFORE appending so the retained body is a
				// hard bound (it never overshoots max_bytes by up to one write chunk).
				if ( strlen( $body ) + strlen( $chunk ) > $max_bytes ) {
					return 0; // Would exceed the size cap -> abort (-> CURLE_WRITE_ERROR -> fail open).
				}
				$body .= $chunk;
				return strlen( $chunk );
			},
		);

		// Pin the connection to the guard-validated IP (DNS-rebinding defence).
		if ( ! empty( $pin['host'] ) && ! empty( $pin['ip'] ) ) {
			$options[ CURLOPT_RESOLVE ] = array( $pin['host'] . ':' . (int) $pin['port'] . ':' . $pin['ip'] );
		}

		if ( null !== $request->body() && 'GET' !== $request->method() ) {
			$options[ CURLOPT_POSTFIELDS ] = $request->body();
		}

		curl_setopt_array( $handle, $options );
		$ok     = curl_exec( $handle );
		$errno  = curl_errno( $handle );
		$status = (int) curl_getinfo( $handle, CURLINFO_RESPONSE_CODE );
		curl_close( $handle );

		if ( false === $ok && 0 !== $errno ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- integer error code in an exception message that is logged, never rendered as HTML.
			throw new Beexy_Connector_Http_Exception( 'cURL transport error ' . (int) $errno );
		}
		if ( 0 === $status ) {
			throw new Beexy_Connector_Http_Exception( 'no upstream response' );
		}

		return new Beexy_Connector_Upstream_Response( $status, $header_lines, $body );
	}
}
