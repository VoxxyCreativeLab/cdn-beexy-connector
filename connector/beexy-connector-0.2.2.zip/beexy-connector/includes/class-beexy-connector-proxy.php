<?php
/**
 * The proxy core orchestrator.
 *
 * Pure except for the two injected I/O seams (HTTP client + DNS resolver). Wires
 * the pipeline and is the single fail-open boundary (contract C-FAIL-1): ANY
 * throwable — config error, SSRF refusal, disallowed method, transport failure,
 * CR/LF in a header — is converted into a benign fail-open response, so the
 * page's tracking is never hard-blocked.
 *
 *   guard(url + DNS pin) -> builder -> [http client] -> header filter + cookie rewrite -> response
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Same-origin reverse-proxy core.
 */
class Beexy_Connector_Proxy {

	/** @var Beexy_Connector_Http_Client_Interface */
	private $client;
	/** @var Beexy_Connector_Ssrf_Guard */
	private $guard;
	/** @var Beexy_Connector_Request_Builder */
	private $builder;
	/** @var Beexy_Connector_Header_Filter */
	private $header_filter;
	/** @var Beexy_Connector_Cookie_Rewriter */
	private $cookie_rewriter;
	/** @var Beexy_Connector_Response_Factory */
	private $response_factory;

	/**
	 * @param Beexy_Connector_Http_Client_Interface   $client   HTTP client seam.
	 * @param Beexy_Connector_Dns_Resolver_Interface  $resolver DNS resolver seam.
	 */
	public function __construct( Beexy_Connector_Http_Client_Interface $client, Beexy_Connector_Dns_Resolver_Interface $resolver ) {
		$this->client           = $client;
		$this->guard            = new Beexy_Connector_Ssrf_Guard( $resolver );
		$this->builder          = new Beexy_Connector_Request_Builder();
		$this->header_filter    = new Beexy_Connector_Header_Filter();
		$this->cookie_rewriter  = new Beexy_Connector_Cookie_Rewriter();
		$this->response_factory = new Beexy_Connector_Response_Factory();
	}

	/**
	 * Proxy one request. Never throws — failure returns a fail-open response.
	 *
	 * @param Beexy_Connector_Proxy_Request $req    Inbound request.
	 * @param Beexy_Connector_Proxy_Config  $config Validated config.
	 * @return Beexy_Connector_Proxy_Response
	 */
	public function handle( Beexy_Connector_Proxy_Request $req, Beexy_Connector_Proxy_Config $config ) {
		try {
			// Path-preserving (C-INT-2): forward the full first-party request path to
			// the upstream host unchanged — the sGTM loader/receiver claims the path
			// itself (e.g. a random first-party loader path), so the prefix is NOT
			// stripped. build_upstream_url still runs the C-SSRF-2 authority-smuggling
			// checks on the forwarded path.
			$forward_path = $req->path();

			$url = $this->guard->build_upstream_url( $config, $forward_path, $req->query() );
			$pin = $this->guard->resolve_and_pin( $config );

			$upstream_request  = $this->builder->build( $req, $config, $url, $pin );
			$upstream_response = $this->client->send( $upstream_request );

			// A redirect is never a valid beacon/loader response. The redirect header is
			// dropped downstream (C-RES-6), so relaying the bare 3xx would be a dead,
			// Location-less response; normalise it to a benign fail-open instead. 304 Not
			// Modified is NOT a redirect — it is relayed so conditional revalidation of the
			// loader script keeps working.
			$status = $upstream_response->status();
			if ( $status >= 300 && $status < 400 && 304 !== $status ) {
				return $this->response_factory->fail_open( $req );
			}

			// Filter (throws on CR/LF) BEFORE rewriting cookies; the two outputs combine.
			$headers = $this->header_filter->filter( $upstream_response->header_lines() );
			$cookies = $this->cookie_rewriter->rewrite( $upstream_response->header_lines(), $config );

			return new Beexy_Connector_Proxy_Response(
				$upstream_response->status(),
				array_merge( $headers, $cookies ),
				$upstream_response->body()
			);
		} catch ( Throwable $e ) {
			unset( $e ); // Fail open on ANY error — never block the page's tracking.
			return $this->response_factory->fail_open( $req );
		}
	}
}
