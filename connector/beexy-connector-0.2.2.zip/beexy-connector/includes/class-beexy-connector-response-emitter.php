<?php
/**
 * WP edge (outbound): emits a pure Proxy_Response to the browser, then exits.
 *
 * The only file that calls header()/http_response_code() and writes output. It
 * disables any server-layer output compression on this path (double-gzip defence)
 * and emits each header line individually so N Set-Cookie lines stay N headers.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Emits the proxied response.
 */
class Beexy_Connector_Response_Emitter {

	/**
	 * Emit and terminate.
	 *
	 * @param Beexy_Connector_Proxy_Response $response Response to emit.
	 * @return void
	 */
	public function emit( Beexy_Connector_Proxy_Response $response ) {
		// Never re-compress a (possibly already-gzipped) proxied body.
		if ( function_exists( 'ini_set' ) ) {
			ini_set( 'zlib.output_compression', 'Off' ); // phpcs:ignore WordPress.PHP.IniSet.Risky -- disabling output compression on the proxy path to prevent double-gzip.
		}
		if ( function_exists( 'apache_setenv' ) ) {
			// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.runtime_configuration_apache_setenv -- disabling gzip on the proxy path (double-gzip defence); intentional and request-scoped.
			apache_setenv( 'no-gzip', '1' );
		}
		while ( ob_get_level() > 0 ) {
			$level = ob_get_level();
			ob_end_clean();
			if ( ob_get_level() >= $level ) {
				// A non-removable buffer (e.g. zlib.output_compression) will not clear;
				// stop rather than spin the worker until max_execution_time.
				break;
			}
		}

		http_response_code( $response->status() );

		foreach ( $response->header_lines() as $line ) {
			// false => do NOT replace: N Set-Cookie lines emit as N headers.
			header( (string) $line, false );
		}

		echo $response->body(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- verbatim proxied body bytes; escaping would corrupt the response.

		exit;
	}
}
