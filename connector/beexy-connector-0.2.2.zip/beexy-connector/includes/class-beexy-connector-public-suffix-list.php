<?php
/**
 * Public Suffix List lookup — the eTLD+1 primitive.
 *
 * Pure: no WordPress, no I/O. Constructed with an array of public-suffix rules
 * (the runtime loads the vendored PSL; tests pass a curated subset). Used by
 * Beexy_Connector_Proxy_Config to validate that cookie_domain is exactly the
 * registrable domain (eTLD+1) of the serving host (contract C-CFG-4).
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Computes registrable domains against a set of public-suffix rules.
 */
class Beexy_Connector_Public_Suffix_List {

	/**
	 * Public-suffix rules, keyed by the rule string for O(1) lookup.
	 *
	 * @var array<string,true>
	 */
	private $rules = array();

	/**
	 * @param string[] $rules Public-suffix rules, e.g. array( 'nl', 'co.uk' ). Case-insensitive.
	 */
	public function __construct( array $rules ) {
		foreach ( $rules as $rule ) {
			$rule = strtolower( trim( (string) $rule, " \t\n\r\0\x0B." ) );
			if ( '' !== $rule ) {
				$this->rules[ $rule ] = true;
			}
		}
	}

	/**
	 * Return the registrable domain (eTLD+1) of a host, or null if the host is
	 * itself a public suffix, is empty, or is malformed.
	 *
	 * @param string $host Hostname.
	 * @return string|null
	 */
	public function registrable_domain( $host ) {
		$host = strtolower( rtrim( (string) $host, '.' ) );

		if ( '' === $host || false !== strpos( $host, '..' ) ) {
			return null;
		}

		$labels = explode( '.', $host );
		$count  = count( $labels );

		// Longest matching public suffix wins; ICANN default is the rightmost label.
		$suffix_len = 1;
		for ( $i = 0; $i < $count; $i++ ) {
			$candidate = implode( '.', array_slice( $labels, $i ) );
			if ( isset( $this->rules[ $candidate ] ) ) {
				$suffix_len = $count - $i;
				break;
			}
		}

		// The host is itself a public suffix — nothing is registrable under it.
		if ( $count <= $suffix_len ) {
			return null;
		}

		return implode( '.', array_slice( $labels, $count - $suffix_len - 1 ) );
	}
}
