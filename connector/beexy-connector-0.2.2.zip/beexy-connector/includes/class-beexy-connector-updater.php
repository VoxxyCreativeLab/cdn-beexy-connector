<?php
/**
 * Private self-hosted auto-update wiring (off-gallery, family ADR-004).
 *
 * WP 5.8 `Update URI` header + the vendored YahnisElsts plugin-update-checker
 * pointed at a Voxxy-controlled channel, with forced auto-update for the fastest
 * security-patch path. Degrades gracefully if the library is not vendored yet.
 *
 * P4 (2026-10-10) adds Ed25519 signature verification of the downloaded package via
 * Beexy_Connector_Update_Verifier (spec/contract.md C-DIST-3).
 * Built per: docs/superpowers/plans/2026-10-10-connector-p4-distribution.md
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Update-channel wiring.
 */
class Beexy_Connector_Updater {

	/**
	 * Wire the update checker (call on plugins_loaded / init).
	 *
	 * @return void
	 */
	public static function init() {
		$library = dirname( BEEXY_CONNECTOR_PLUGIN_FILE ) . '/vendor/plugin-update-checker/plugin-update-checker.php';
		if ( ! is_file( $library ) ) {
			return; // Library not vendored — no update channel wired (plugin still fully functional).
		}
		require_once $library;

		$url = defined( 'BEEXY_CONNECTOR_UPDATE_URL' )
			? (string) BEEXY_CONNECTOR_UPDATE_URL
			: Beexy_Connector_Constants::DEFAULT_UPDATE_URL;

		if ( class_exists( 'YahnisElsts\\PluginUpdateChecker\\v5\\PucFactory' ) ) {
			\YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
				$url,
				BEEXY_CONNECTOR_PLUGIN_FILE,
				Beexy_Connector_Constants::SLUG
			);
		} elseif ( class_exists( 'Puc_v4_Factory' ) ) {
			\Puc_v4_Factory::buildUpdateChecker(
				$url,
				BEEXY_CONNECTOR_PLUGIN_FILE,
				Beexy_Connector_Constants::SLUG
			);
		} else {
			return;
		}

		// Forced auto-update for this plugin (fastest controlled security-patch path).
		add_filter( 'auto_update_plugin', array( __CLASS__, 'force_auto_update' ), 10, 2 );

		// Verify the Ed25519 signature of our package before WordPress installs it
		// (Option C, spec/contract.md C-DIST-3). Fails closed on a bad/absent signature.
		Beexy_Connector_Update_Verifier::init();
	}

	/**
	 * Force auto-update for this plugin only.
	 *
	 * @param bool   $update Whether to auto-update.
	 * @param object $item   Update offer object.
	 * @return bool
	 */
	public static function force_auto_update( $update, $item ) {
		if ( isset( $item->plugin ) && plugin_basename( BEEXY_CONNECTOR_PLUGIN_FILE ) === $item->plugin ) {
			return true;
		}
		return $update;
	}
}
