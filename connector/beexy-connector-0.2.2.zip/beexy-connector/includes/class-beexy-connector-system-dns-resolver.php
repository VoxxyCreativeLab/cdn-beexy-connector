<?php
/**
 * Real DNS resolver (runtime implementation of the resolver seam).
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Resolves hostnames via the system resolver.
 */
class Beexy_Connector_System_Dns_Resolver implements Beexy_Connector_Dns_Resolver_Interface {

	/**
	 * @param string $host Hostname.
	 * @return string[] Resolved IPv4/IPv6 addresses (empty on failure).
	 */
	public function resolve( $host ) {
		$host = (string) $host;
		$ips  = array();

		$a = gethostbynamel( $host );
		if ( is_array( $a ) ) {
			$ips = array_merge( $ips, $a );
		}

		if ( function_exists( 'dns_get_record' ) && defined( 'DNS_AAAA' ) ) {
			$records = dns_get_record( $host, DNS_AAAA );
			if ( is_array( $records ) ) {
				foreach ( $records as $record ) {
					if ( ! empty( $record['ipv6'] ) ) {
						$ips[] = (string) $record['ipv6'];
					}
				}
			}
		}

		return array_values( array_unique( $ips ) );
	}
}
