<?php
/**
 * Thrown when an upstream request fails or a response cannot be safely proxied.
 *
 * Covers transport failures/timeouts (from the HTTP client) and response-integrity
 * failures (e.g. CR/LF in a header). Every such throwable is caught by
 * Beexy_Connector_Proxy and converted into a fail-open response (contract C-FAIL-1).
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Upstream transport / response-integrity failure.
 */
class Beexy_Connector_Http_Exception extends RuntimeException {
}
