<?php
/**
 * Builds the upstream request from the inbound request + validated config.
 *
 * Pure: no WordPress, no I/O. Contract C-REQ-1..6:
 *
 *  - forwards Cookie verbatim,
 *  - forces Host to the upstream host,
 *  - strips hop-by-hop headers,
 *  - drops every client-supplied forwarding / client-IP / URL-override header and
 *    sets X-Forwarded-For from the trusted client IP (REMOTE_ADDR) only,
 *  - enforces the method allowlist (disallowed -> throw -> fail open),
 *  - relays Accept-Encoding unchanged (gzip pass-through) and the body verbatim.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Upstream request builder.
 */
class Beexy_Connector_Request_Builder {

	/**
	 * Hop-by-hop headers (RFC 7230 6.1) never forwarded upstream.
	 *
	 * @var string[]
	 */
	private static $hop_by_hop = array(
		'connection',
		'keep-alive',
		'proxy-authenticate',
		'proxy-authorization',
		'te',
		'trailer',
		'transfer-encoding',
		'upgrade',
	);

	/**
	 * Client-supplied forwarding / client-IP / URL-override headers. None may reach the
	 * backend: the sGTM (or a reverse proxy in front of it) may trust them for the client
	 * IP, absolute-URL/host generation, or routing, so an inbound value is host / IP / URL
	 * poisoning. The proxy sets its own X-Forwarded-For from the trusted REMOTE_ADDR. Any
	 * `x-forwarded-*` header is caught by prefix; these are the non-prefixed siblings.
	 *
	 * @var string[]
	 */
	private static $forwarding_spoof = array(
		'forwarded',
		'x-real-ip',
		'true-client-ip',
		'cf-connecting-ip',
		'x-client-ip',
		'x-cluster-client-ip',
		'fastly-client-ip',
		'x-original-host',
		'x-original-url',
		'x-rewrite-url',
	);

	/**
	 * Build the upstream request.
	 *
	 * @param Beexy_Connector_Proxy_Request $req    Inbound request.
	 * @param Beexy_Connector_Proxy_Config  $config Validated config.
	 * @param string                        $url    Pre-built, allowlist-only upstream URL (from the SSRF guard).
	 * @param array                         $pin    DNS resolve pin (from the SSRF guard).
	 * @return Beexy_Connector_Upstream_Request
	 * @throws Beexy_Connector_Http_Exception If the method is not allowed.
	 */
	public function build( Beexy_Connector_Proxy_Request $req, Beexy_Connector_Proxy_Config $config, $url, array $pin ) {
		$method = $req->method();
		if ( ! $config->is_method_allowed( $method ) ) {
			throw new Beexy_Connector_Http_Exception( 'HTTP method not allowed' );
		}

		$headers = array();
		// Host is forced to the upstream, never the serving host.
		$headers[] = 'Host: ' . $config->upstream_host();

		foreach ( $req->headers() as $name => $value ) {
			$lname = strtolower( trim( (string) $name ) );
			if ( in_array( $lname, self::$hop_by_hop, true ) ) {
				continue;
			}
			if ( 'host' === $lname ) {
				continue; // forced above
			}
			if ( 'x-gtm-server-preview' === $lname ) {
				continue; // never let a client drive the sGTM preview/debug state through the proxy
			}
			if ( self::is_spoofable_forwarding_header( $lname ) ) {
				continue; // never trust a client-supplied forwarding / client-IP / URL-override header
			}
			$headers[] = $name . ': ' . $value;
		}

		// The real client IP, from the trusted REMOTE_ADDR only.
		$headers[] = 'X-Forwarded-For: ' . $req->remote_addr();

		return new Beexy_Connector_Upstream_Request(
			$method,
			(string) $url,
			$headers,
			$req->body(),
			$pin,
			$config->connect_timeout_ms(),
			$config->total_timeout_ms(),
			$config->max_bytes()
		);
	}

	/**
	 * Is a (lower-cased) header name a client-supplied forwarding / client-IP /
	 * URL-override header that must not be relayed to the backend?
	 *
	 * @param string $lname Lower-cased header name.
	 * @return bool
	 */
	private static function is_spoofable_forwarding_header( $lname ) {
		if ( 0 === strpos( $lname, 'x-forwarded-' ) ) {
			return true; // x-forwarded-for / -host / -proto / -port / -ssl / -server / -scheme / ...
		}
		return in_array( $lname, self::$forwarding_spoof, true );
	}
}
