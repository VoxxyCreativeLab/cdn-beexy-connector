<?php
/**
 * The WP entry point for the proxy.
 *
 * Runs as early as a normal plugin can (called from the main file at plugin-load).
 * A cheap REQUEST_URI prefix check against the claimed path(s) — read from the
 * wp-config constant, or (constant absent) derived from the pasted sGTM URL /
 * Pixel-path options (autoloaded) — gates almost every request at near-zero cost;
 * only a matching request loads the full config and runs the core, then emits and
 * exits. The authoritative boundary re-check is Config::path_matches(). The public
 * endpoint is intentionally nonceless (anonymous beacon traffic) — see phpcs.xml.dist.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Proxy interceptor.
 */
class Beexy_Connector_Interceptor {

	/** @var bool Guards against double handling (main file + mu-loader). */
	private static $handled = false;

	/**
	 * Intercept a matching request; otherwise return and let WordPress proceed.
	 *
	 * @return void
	 */
	public static function maybe_handle() {
		if ( self::$handled ) {
			return;
		}

		$proxy_paths = self::configured_paths();
		if ( empty( $proxy_paths ) ) {
			return; // Not configured.
		}

		$path = self::current_path();
		// Boundary-aware match against ANY claimed path: a claimed path exactly, or
		// followed by '/'. A bare string-prefix would let '/collect' capture
		// '/collections' (route hijack). This mirrors Config::path_matches(), which
		// re-checks authoritatively against the validated config below.
		$matched = false;
		foreach ( $proxy_paths as $claimed ) {
			if ( $path === $claimed || 0 === strncmp( $path, $claimed . '/', strlen( $claimed ) + 1 ) ) {
				$matched = true;
				break;
			}
		}
		if ( ! $matched ) {
			return; // Not our path — cheap exit, no config load.
		}

		self::$handled = true;

		// License gate (F3). A cached read, NEVER a network call on the hot path
		// (C-LIC-3): Off/Watch (Watch is the default) return allow immediately. Only
		// Block mode with a confirmed valid:false declines here (fail-closed on an
		// explicit license deny), so the Connector serves the same-origin path ONLY
		// for a licensed domain. Declining lets WordPress handle the request normally.
		if ( ! Beexy_Connector_License::get_instance()->is_allowed() ) {
			return;
		}

		$config = Beexy_Connector_Config::load();
		if ( null === $config ) {
			return; // Invalid/unconfigured — fail open by NOT intercepting.
		}
		if ( ! $config->path_matches( $path ) ) {
			return; // Authoritative boundary check against the validated proxy path.
		}

		$reader   = new Beexy_Connector_Request_Reader();
		$proxy    = new Beexy_Connector_Proxy(
			new Beexy_Connector_Curl_Http_Client(),
			new Beexy_Connector_System_Dns_Resolver()
		);
		$response = $proxy->handle( $reader->read(), $config );

		$emitter = new Beexy_Connector_Response_Emitter();
		$emitter->emit( $response ); // Emits and exits.
	}

	/**
	 * The current request path (no query string).
	 *
	 * @return string
	 */
	private static function current_path() {
		if ( ! isset( $_SERVER['REQUEST_URI'] ) ) {
			return '/';
		}
		$uri  = (string) wp_unslash( $_SERVER['REQUEST_URI'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- used for a strpos prefix match; the sub-path is validated by the SSRF guard.
		$qpos = strpos( $uri, '?' );
		return ( false === $qpos ) ? $uri : substr( $uri, 0, $qpos );
	}

	/**
	 * The claimed proxy path(s), read cheaply for the early gate: the wp-config
	 * PROXY_PATH constant (legacy/locked) wins; otherwise derived from the pasted
	 * sGTM URL option (the loader path) + an optional Pixel event path option.
	 * Authoritative validation is deferred to Config::load() / from_source().
	 *
	 * @return string[] Normalised claimed paths (empty when unconfigured).
	 */
	private static function configured_paths() {
		$name = Beexy_Connector_Constants::$critical_constants['proxy_path'];
		if ( defined( $name ) ) {
			$path = self::normalise_path( (string) constant( $name ) );
			return ( null === $path ) ? array() : array( $path );
		}

		$paths = array();
		// Mirror Config::build_raw()'s upstream resolution so the cheap early gate and
		// the authoritative config agree on the claimed path: the UPSTREAM_BASE
		// constant wins over the pasted-URL option (else a constants install that
		// embeds the path in the base would build a valid config the gate never matches).
		$upstream_const = Beexy_Connector_Constants::$critical_constants['upstream_base'];
		$sgtm           = defined( $upstream_const ) ? (string) constant( $upstream_const ) : (string) get_option( 'beexy_connector_sgtm_url', '' );
		if ( '' !== $sgtm ) {
			$loader = self::normalise_path( (string) wp_parse_url( $sgtm, PHP_URL_PATH ) );
			if ( null !== $loader ) {
				$paths[] = $loader;
			}
		}
		$pixel = self::normalise_path( (string) get_option( 'beexy_connector_pixel_path', '' ) );
		if ( null !== $pixel ) {
			$paths[] = $pixel;
		}
		return $paths;
	}

	/**
	 * Normalise a path to leading-slash, no-trailing-slash form, or null when empty
	 * or the site root.
	 *
	 * @param string $path Raw path.
	 * @return string|null
	 */
	private static function normalise_path( $path ) {
		if ( '' === $path || '/' !== $path[0] ) {
			return null;
		}
		$normalised = '/' . trim( $path, '/' );
		return ( '/' === $normalised ) ? null : $normalised;
	}
}
