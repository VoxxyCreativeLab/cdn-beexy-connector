<?php
/**
 * SSRF guard — the security core.
 *
 * Pure logic + an injected DNS resolver (the only I/O seam). Contract C-SSRF-1..4:
 *
 *  - builds the upstream URL from the allowlisted base only (never request-derived host),
 *  - rejects authority smuggling in the sub-path (scheme, //, backslash, @, CR/LF),
 *  - resolves the upstream host and refuses if ANY resolved IP is non-public,
 *  - pins a validated IP so the connection cannot be re-pointed (DNS rebinding).
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Egress / SSRF guard.
 */
class Beexy_Connector_Ssrf_Guard {

	/** @var Beexy_Connector_Dns_Resolver_Interface */
	private $resolver;

	/**
	 * @param Beexy_Connector_Dns_Resolver_Interface $resolver DNS resolution seam.
	 */
	public function __construct( Beexy_Connector_Dns_Resolver_Interface $resolver ) {
		$this->resolver = $resolver;
	}

	/**
	 * Build the upstream URL from the allowlisted base + a validated sub-path.
	 *
	 * @param Beexy_Connector_Proxy_Config $config  Validated config.
	 * @param string                       $subpath Path after the proxy-path prefix.
	 * @param string                       $query   Query string (no leading '?').
	 * @return string
	 * @throws Beexy_Connector_Http_Exception On authority smuggling / illegal characters.
	 */
	public function build_upstream_url( Beexy_Connector_Proxy_Config $config, $subpath, $query ) {
		$subpath = (string) $subpath;
		$query   = (string) $query;

		if ( preg_match( '#[\r\n\\\\]#', $subpath ) ) {
			throw new Beexy_Connector_Http_Exception( 'illegal characters in proxy sub-path' );
		}
		if ( false !== strpos( $subpath, '@' ) ) {
			throw new Beexy_Connector_Http_Exception( 'authority smuggling in proxy sub-path' );
		}
		if ( false !== strpos( $subpath, '//' ) ) {
			throw new Beexy_Connector_Http_Exception( 'protocol-relative authority in proxy sub-path' );
		}
		if ( false !== strpos( $subpath, '://' ) ) {
			throw new Beexy_Connector_Http_Exception( 'scheme in proxy sub-path' );
		}
		if ( preg_match( '#[\r\n]#', $query ) ) {
			throw new Beexy_Connector_Http_Exception( 'illegal characters in query string' );
		}

		$url = $config->upstream_base() . '/' . ltrim( $subpath, '/' );
		if ( '' !== $query ) {
			$url .= '?' . $query;
		}
		return $url;
	}

	/**
	 * Resolve the upstream host, refuse any non-public IP, and return a pin.
	 *
	 * @param Beexy_Connector_Proxy_Config $config Validated config.
	 * @return array{host:string,port:int,ip:string}
	 * @throws Beexy_Connector_Http_Exception On resolution failure or a non-public IP.
	 */
	public function resolve_and_pin( Beexy_Connector_Proxy_Config $config ) {
		$host = $config->upstream_host();
		$ips  = $this->resolver->resolve( $host );

		if ( empty( $ips ) ) {
			throw new Beexy_Connector_Http_Exception( 'DNS resolution failed for the upstream host' );
		}
		foreach ( $ips as $ip ) {
			if ( ! $this->is_public_ip( $ip ) ) {
				throw new Beexy_Connector_Http_Exception( 'upstream resolves to a non-public IP address' );
			}
		}

		return array(
			'host' => $host,
			'port' => $config->upstream_port(),
			'ip'   => (string) $ips[0],
		);
	}

	/**
	 * Is an IP address publicly routable (not private / loopback / link-local / reserved)?
	 *
	 * @param string $ip IP address.
	 * @return bool
	 */
	public function is_public_ip( $ip ) {
		$ip = strtolower( trim( (string) $ip ) );

		if ( false === filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return false;
		}

		// IPv6 can EMBED an IPv4 that filter_var's NO_PRIV/NO_RES flags do not see
		// through, so `::ffff:169.254.169.254`, 6to4, NAT64, Teredo, etc. would wrongly
		// classify as public — a DNS-rebinding SSRF bypass. Look through those forms.
		if ( false !== strpos( $ip, ':' ) ) {
			$bin = inet_pton( $ip ); // Safe: $ip already passed FILTER_VALIDATE_IP.
			if ( is_string( $bin ) && 16 === strlen( $bin ) ) {
				$embedded = self::embedded_ipv4( $bin );
				if ( null !== $embedded ) {
					return self::is_public_ipv4( $embedded );
				}
				if ( self::is_obfuscated_ipv4_embedding( $bin ) ) {
					return false; // Teredo / local-use NAT64 — never a legitimate upstream.
				}
			}
		}

		if ( false === filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
			return false;
		}
		// Belt-and-suspenders for IPv6 ranges some PHP builds treat leniently.
		if ( '::1' === $ip
			|| 0 === strpos( $ip, 'fe80' )   // link-local
			|| 0 === strpos( $ip, 'fc' )     // unique-local (fc00::/7)
			|| 0 === strpos( $ip, 'fd' ) ) {
			return false;
		}
		return true;
	}

	/**
	 * Is a dotted IPv4 publicly routable?
	 *
	 * @param string $v4 Dotted IPv4.
	 * @return bool
	 */
	private static function is_public_ipv4( $v4 ) {
		return false !== filter_var(
			$v4,
			FILTER_VALIDATE_IP,
			FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
		);
	}

	/**
	 * If a 16-byte IPv6 embeds an IPv4 in a contiguous, unambiguous layout, return
	 * that IPv4 in dotted form; otherwise null. Covers IPv4-mapped / deprecated-compat
	 * / NAT64 well-known (`/96`, trailing 32 bits) and 6to4 (`2002::/16`, the two
	 * groups after the prefix). Works at the binary level, so it is encoding-agnostic.
	 *
	 * @param string $bin 16-byte packed IPv6 (from inet_pton).
	 * @return string|null Embedded IPv4 (dotted) or null.
	 */
	private static function embedded_ipv4( $bin ) {
		$prefix      = substr( $bin, 0, 12 );
		$trailing_v4 = ( "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff" === $prefix ) // IPv4-mapped.
			|| ( "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00" === $prefix )         // all-zero high 96 bits.
			|| ( "\x00\x64\xff\x9b\x00\x00\x00\x00\x00\x00\x00\x00" === $prefix );        // NAT64 well-known.
		if ( $trailing_v4 ) {
			$v4 = inet_ntop( substr( $bin, 12, 4 ) );
			return ( false === $v4 ) ? null : $v4;
		}
		if ( "\x20\x02" === substr( $bin, 0, 2 ) ) { // 6to4 (2002::/16): IPv4 is bytes 2-5.
			$v4 = inet_ntop( substr( $bin, 2, 4 ) );
			return ( false === $v4 ) ? null : $v4;
		}
		return null;
	}

	/**
	 * IPv4-embedding forms whose IPv4 is obfuscated or bit-split (Teredo `2001:0::/32`;
	 * RFC-8215 local-use NAT64 `64:ff9b:1::/48`). A legitimate upstream is never at such
	 * an address, so the guard refuses them outright rather than decode the payload.
	 *
	 * @param string $bin 16-byte packed IPv6.
	 * @return bool
	 */
	private static function is_obfuscated_ipv4_embedding( $bin ) {
		return "\x20\x01\x00\x00" === substr( $bin, 0, 4 )      // Teredo 2001:0000::/32.
			|| "\x00\x64\xff\x9b\x00\x01" === substr( $bin, 0, 6 ); // Local-use NAT64 64:ff9b:1::/48.
	}
}
