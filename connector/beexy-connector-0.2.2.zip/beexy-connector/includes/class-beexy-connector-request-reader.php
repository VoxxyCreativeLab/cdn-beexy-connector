<?php
/**
 * WP edge (inbound): builds a pure Proxy_Request from the superglobals.
 *
 * This is one of only two files that touch $_SERVER / getallheaders() / php://input.
 * Values forwarded verbatim to the trusted upstream (headers, cookie, body, path,
 * query) are NOT sanitised — sanitising would corrupt the proxied request, and the
 * SSRF guard validates the forwarded sub-path. Security-relevant values (method,
 * remote IP) are validated. The public endpoint is intentionally nonceless (it
 * serves anonymous beacon traffic) — see phpcs.xml.dist.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Reads the inbound request from the PHP/WP edge.
 */
class Beexy_Connector_Request_Reader {

	/**
	 * Build the Proxy_Request from the PHP/WP edge.
	 *
	 * @return Beexy_Connector_Proxy_Request
	 */
	public function read() {
		$method = isset( $_SERVER['REQUEST_METHOD'] )
			? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) )
			: 'GET';

		// REQUEST_URI is split into path (used for prefix match + guard-validated sub-path)
		// and query (forwarded verbatim). Not sanitised: forwarded to the trusted upstream.
		$request_uri = isset( $_SERVER['REQUEST_URI'] )
			? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- forwarded verbatim; sub-path validated by the SSRF guard.
			: '/';
		$path        = $request_uri;
		$query       = '';
		$qpos        = strpos( $request_uri, '?' );
		if ( false !== $qpos ) {
			$path  = substr( $request_uri, 0, $qpos );
			$query = substr( $request_uri, $qpos + 1 );
		}

		return new Beexy_Connector_Proxy_Request(
			$method,
			$path,
			$query,
			$this->headers(),
			$this->body( $method ),
			$this->remote_addr()
		);
	}

	/**
	 * Read request headers, forwarded verbatim.
	 *
	 * @return array<string,string>
	 */
	private function headers() {
		$headers = array();

		if ( function_exists( 'getallheaders' ) ) {
			$raw = getallheaders();
			if ( is_array( $raw ) ) {
				foreach ( $raw as $name => $value ) {
					$headers[ (string) $name ] = (string) $value;
				}
			}
		}

		// Fallback / portability: reconstruct from HTTP_* when getallheaders is thin.
		if ( empty( $headers ) ) {
			foreach ( $_SERVER as $key => $value ) {
				if ( 0 === strpos( (string) $key, 'HTTP_' ) ) {
					$name             = str_replace( ' ', '-', ucwords( strtolower( str_replace( '_', ' ', substr( (string) $key, 5 ) ) ) ) );
					$headers[ $name ] = (string) wp_unslash( $value ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- forwarded verbatim.
				}
			}
			if ( isset( $_SERVER['CONTENT_TYPE'] ) ) {
				$headers['Content-Type'] = (string) wp_unslash( $_SERVER['CONTENT_TYPE'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- forwarded verbatim.
			}
			if ( isset( $_SERVER['CONTENT_LENGTH'] ) ) {
				$headers['Content-Length'] = (string) wp_unslash( $_SERVER['CONTENT_LENGTH'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- forwarded verbatim.
			}
		}

		return $headers;
	}

	/**
	 * Read the raw request body for non-idempotent methods.
	 *
	 * @param string $method HTTP method.
	 * @return string|null
	 */
	private function body( $method ) {
		if ( 'GET' === $method || 'HEAD' === $method ) {
			return null;
		}
		// Raw beacon body: there is no WP_Filesystem equivalent for php://input.
		$body = file_get_contents( 'php://input' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- reading the raw request body; no WP API exists.
		return ( false === $body ) ? null : $body;
	}

	/**
	 * Determine the trusted client IP (REMOTE_ADDR, or a constant-gated trusted header).
	 *
	 * @return string
	 */
	private function remote_addr() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] )
			? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) )
			: '';

		// Opt-in trusted-proxy mode (default off): lift the real IP from a named header.
		if ( defined( 'BEEXY_CONNECTOR_TRUSTED_PROXY_HEADER' ) && BEEXY_CONNECTOR_TRUSTED_PROXY_HEADER ) {
			$server_key = 'HTTP_' . strtoupper( str_replace( '-', '_', (string) BEEXY_CONNECTOR_TRUSTED_PROXY_HEADER ) );
			if ( isset( $_SERVER[ $server_key ] ) ) {
				$candidate = sanitize_text_field( wp_unslash( $_SERVER[ $server_key ] ) );
				$parts     = explode( ',', $candidate );
				$first     = trim( (string) $parts[0] );
				if ( filter_var( $first, FILTER_VALIDATE_IP ) ) {
					$ip = $first;
				}
			}
		}

		return $ip;
	}
}
