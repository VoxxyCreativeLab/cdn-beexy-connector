<?php
/**
 * Loads the vendored Public Suffix List rules for the runtime.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * PSL rules loader.
 */
class Beexy_Connector_Psl_Loader {

	/**
	 * Return the bundled public-suffix rules (multi-label suffixes).
	 *
	 * @return string[]
	 */
	public static function rules() {
		$file = dirname( BEEXY_CONNECTOR_PLUGIN_FILE ) . '/vendor/public-suffix-list/rules.php';
		if ( is_file( $file ) ) {
			$rules = require $file;
			if ( is_array( $rules ) ) {
				return $rules;
			}
		}
		return array();
	}
}
