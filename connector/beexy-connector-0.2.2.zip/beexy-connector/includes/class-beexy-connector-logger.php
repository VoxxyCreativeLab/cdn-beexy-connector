<?php
/**
 * Minimal PSR-3-flavoured logger.
 *
 * Off by default and never on the hot beacon path. Writes to error_log only when
 * WP_DEBUG is on, so a misconfiguration surfaces in dev without adding latency or
 * disk churn in production.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Diagnostic logger.
 */
class Beexy_Connector_Logger {

	use Beexy_Connector_Singleton;

	/**
	 * Log a warning-level message (only when WP_DEBUG is enabled).
	 *
	 * @param string $message Message.
	 * @param array  $context Optional context.
	 * @return void
	 */
	public function warning( $message, array $context = array() ) {
		if ( ! ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ) {
			return;
		}
		$suffix = empty( $context ) ? '' : ' ' . wp_json_encode( $context );
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- gated on WP_DEBUG; diagnostics only.
		error_log( '[beexy-connector] ' . (string) $message . $suffix );
	}
}
