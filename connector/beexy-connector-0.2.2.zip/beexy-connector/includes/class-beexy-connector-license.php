<?php
/**
 * License gate: F3 wiring to the 0017 account-scoped License key.
 *
 * Contract C-LIC-1..3: exactly ONE enforcement point (is_allowed), shaped so the
 * 0017 verdict slots in with no caller change. The plugin still ships fully
 * functional with no key. Off, or no key, returns allow (C-LIC-2).
 *
 * The validation network call lives OFF the hot beacon path: refresh() is run by a
 * daily cron + on the admin page + by the Verify button. is_allowed() reads ONLY the
 * cached verdict and NEVER makes a network call (C-LIC-3). Fail-open is locked:
 * deny ONLY on an explicit valid:false; any response lacking a `valid` field (5xx,
 * 429 rate-limit, timeout, network error) keeps the last cached-good verdict,
 * bounded by the cache TTL (0017 license-contract.md §4/§7). Analytics must never
 * take down a paying site.
 *
 * The 0017 Gate derives the asking domain server-side (0017 contract §4/§5). The
 * Connector, a server-side caller with no browser Origin, sends its own serving host
 * in the X-Beexy-Domain header and the key in the POST body (never a domain in the
 * body, never an Authorization header, which reintroduces the preflight that broke TAGGRS).
 *
 * Built per: docs/superpowers/plans/2026-10-10-connector-f3.md
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Single license enforcement point + its off-hot-path refresh.
 */
class Beexy_Connector_License {

	use Beexy_Connector_Singleton;

	const OPT_KEY           = 'beexy_connector_license_key';
	const OPT_MODE          = 'beexy_connector_license_mode';
	const VERDICT_TRANSIENT = 'beexy_connector_license_verdict';

	/**
	 * The single enforcement point. Hot-path safe: cached reads only, NEVER a
	 * network call (C-LIC-3). Returns allow unless Block mode holds an explicit
	 * valid:false verdict for this domain.
	 *
	 * @return bool
	 */
	public function is_allowed() {
		$mode = $this->mode();
		if ( Beexy_Connector_Constants::LICENSE_MODE_OFF === $mode ) {
			return true;
		}
		if ( '' === $this->key() ) {
			return true; // Ships functional with no key (C-LIC-2).
		}
		if ( Beexy_Connector_Constants::LICENSE_MODE_BLOCK !== $mode ) {
			return true; // Watch: observe + surface only; never changes serving.
		}
		$verdict = get_transient( self::VERDICT_TRANSIENT );
		if ( ! is_array( $verdict ) || ! array_key_exists( 'valid', $verdict ) ) {
			return true; // No cached verdict yet -> fail open (keep serving).
		}
		if ( false === $verdict['valid'] ) {
			return false; // Deny ONLY on an explicit valid:false.
		}
		// A wildcard (all-domains) key is Consent-only; the Connector is a non-Consent
		// consumer and rejects it, like Identity / Transport / Warehouse (0017 contract section 5).
		if ( ! empty( $verdict['is_wildcard'] ) ) {
			return false;
		}
		return true;
	}

	/**
	 * Fetch + cache the verdict. Runs OFF the hot path (cron / admin / Verify). On
	 * any response without an explicit `valid` field the last cached-good is kept.
	 *
	 * @return array<string,mixed>|null The current verdict, or null when no key.
	 */
	public function refresh() {
		$key = $this->key();
		if ( '' === $key ) {
			delete_transient( self::VERDICT_TRANSIENT );
			return null;
		}
		$response = wp_remote_post(
			$this->endpoint(),
			array(
				'timeout'     => 5,
				'redirection' => 0,
				'headers'     => array(
					'Content-Type'   => 'application/json',
					'X-Beexy-Domain' => $this->serving_host(),
				),
				'body'        => wp_json_encode( array( 'key' => $key ) ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return $this->current_verdict(); // Our-unavailability -> keep last-good.
		}
		$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		// Any response lacking an explicit verdict (5xx / 429 / garbage) -> keep last-good.
		if ( ! is_array( $body ) || ! array_key_exists( 'valid', $body ) ) {
			return $this->current_verdict();
		}
		set_transient( self::VERDICT_TRANSIENT, $body, Beexy_Connector_Constants::LICENSE_CACHE_TTL );
		if ( false === $body['valid'] ) {
			Beexy_Connector_Logger::get_instance()->warning(
				'license: not licensed for this domain',
				array(
					'domain' => $this->serving_host(),
					'reason' => isset( $body['reason'] ) ? (string) $body['reason'] : '',
				)
			);
		}
		return $body;
	}

	/**
	 * Cron entry point. Static so bootstrap can register it without instantiating
	 * the gate on the hot path; the instance is built only when the event fires.
	 *
	 * @return void
	 */
	public static function cron_refresh() {
		self::get_instance()->refresh();
	}

	/**
	 * Ensure the daily refresh event exists. Called on `init` as well as on
	 * activation, because WordPress does NOT run the activation hook on a plugin
	 * auto-update and this plugin auto-updates, so an install upgrading into F3 would
	 * otherwise never schedule the background re-check. Idempotent (guarded).
	 *
	 * @return void
	 */
	public static function ensure_scheduled() {
		if ( ! wp_next_scheduled( Beexy_Connector_Constants::LICENSE_CRON_HOOK ) ) {
			wp_schedule_event( time(), 'daily', Beexy_Connector_Constants::LICENSE_CRON_HOOK );
		}
	}

	/**
	 * The last cached verdict, or null when none is cached.
	 *
	 * @return array<string,mixed>|null
	 */
	public function current_verdict() {
		$verdict = get_transient( self::VERDICT_TRANSIENT );
		return is_array( $verdict ) ? $verdict : null;
	}

	/**
	 * The enforcement mode: constant wins, else the option, else Watch (the safe
	 * default, observe before enforcing). An unknown value falls back to Watch.
	 *
	 * @return string One of LICENSE_MODE_OFF|WATCH|BLOCK.
	 */
	public function mode() {
		$value = $this->from_constant( 'license_mode' );
		if ( null === $value ) {
			$value = get_option( self::OPT_MODE, Beexy_Connector_Constants::LICENSE_MODE_WATCH );
		}
		$value   = is_string( $value ) ? strtolower( trim( $value ) ) : '';
		$allowed = array(
			Beexy_Connector_Constants::LICENSE_MODE_OFF,
			Beexy_Connector_Constants::LICENSE_MODE_WATCH,
			Beexy_Connector_Constants::LICENSE_MODE_BLOCK,
		);
		return in_array( $value, $allowed, true ) ? $value : Beexy_Connector_Constants::LICENSE_MODE_WATCH;
	}

	/**
	 * The account-scoped license key: constant wins, else the option, else empty.
	 *
	 * @return string
	 */
	public function key() {
		$value = $this->from_constant( 'license_key' );
		if ( null === $value ) {
			$value = get_option( self::OPT_KEY, '' );
		}
		return is_string( $value ) ? trim( $value ) : '';
	}

	/**
	 * True when a wp-config constant pins the key (UI renders it read-only).
	 *
	 * @return bool
	 */
	public function key_is_locked() {
		return null !== $this->from_constant( 'license_key' );
	}

	/**
	 * True when a wp-config constant pins the mode (UI renders the selector read-only).
	 *
	 * @return bool
	 */
	public function mode_is_locked() {
		return null !== $this->from_constant( 'license_mode' );
	}

	/**
	 * The Gate endpoint: the BEEXY_CONNECTOR_LICENSE_URL constant wins (the raw-ref
	 * testing path), else the stable license.beexy.io default.
	 *
	 * @return string
	 */
	private function endpoint() {
		$value = $this->from_constant( 'license_url' );
		return ( is_string( $value ) && '' !== $value ) ? $value : Beexy_Connector_Constants::DEFAULT_LICENSE_URL;
	}

	/**
	 * The host this install presents to the Gate: the SERVING_HOST constant if set
	 * (matching the proxy), else the site's own home_url() host. The Gate normalises
	 * it to eTLD+1. NEVER the request Host header (attacker-controlled).
	 *
	 * @return string
	 */
	private function serving_host() {
		$const = Beexy_Connector_Constants::$critical_constants['serving_host'];
		if ( defined( $const ) && '' !== (string) constant( $const ) ) {
			return (string) constant( $const );
		}
		$host = wp_parse_url( (string) home_url(), PHP_URL_HOST );
		return is_string( $host ) ? $host : '';
	}

	/**
	 * Read a license value from its wp-config constant, or null when undefined.
	 *
	 * @param string $key Logical key in Constants::$license_constants.
	 * @return mixed|null
	 */
	private function from_constant( $key ) {
		$name = isset( Beexy_Connector_Constants::$license_constants[ $key ] )
			? Beexy_Connector_Constants::$license_constants[ $key ]
			: '';
		return ( '' !== $name && defined( $name ) ) ? constant( $name ) : null;
	}
}
