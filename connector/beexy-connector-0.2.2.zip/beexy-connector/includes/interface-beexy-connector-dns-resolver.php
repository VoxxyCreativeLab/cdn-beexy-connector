<?php
/**
 * DNS resolution seam.
 *
 * Injected into Beexy_Connector_Ssrf_Guard so the pure core can validate that an
 * upstream resolves only to public IPs (contract C-SSRF-3) and pin a vetted IP
 * (C-SSRF-4) without opening a socket in unit tests. The runtime implementation
 * does real resolution; tests supply a fake with canned IPs.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Resolves a hostname to its IP addresses.
 */
interface Beexy_Connector_Dns_Resolver_Interface {

	/**
	 * Resolve a hostname to a list of IP address strings (IPv4 and/or IPv6).
	 *
	 * @param string $host Hostname to resolve.
	 * @return string[] Resolved IPs (may be empty on failure).
	 */
	public function resolve( $host );
}
