<?php
/**
 * Update-package integrity: verify the Ed25519 signature of a downloaded update
 * ZIP against an embedded public key BEFORE WordPress installs it, and refuse a
 * rollback to an older version than the one running.
 *
 * Why (P4, spec/contract.md C-DIST-3): the Connector forces auto-updates
 * (class-beexy-connector-updater.php) from a Voxxy-controlled, PUBLIC channel
 * (updates.beexy.io, backed by the cdn-beexy-connector GitHub repo). A signature
 * made with a key held OFFLINE moves the trust anchor off the host: a tampered or
 * swapped ZIP fails verification wherever it is served, so a compromised host can
 * never inject code. It could still try to roll an install back to an older,
 * still-validly-signed release (by advertising a high version in info.json while
 * pointing download_url at the old ZIP), so after authenticity is proven we also
 * refuse a package whose own (signed) version is below the installed one. That
 * downgrade check is best-effort: it runs when the package version is readable;
 * the signature (authenticity) is the mandatory gate and always runs.
 *
 * This is the ONE place the Connector fails CLOSED: an unverifiable update is
 * refused (WordPress keeps the running version, no brick). That is deliberate and
 * is the OPPOSITE of the proxy hot path, which fails OPEN. Do not change it.
 *
 * The signature is published next to the package as `<download_url>.sig` (base64 of
 * the raw 64-byte detached signature); the public key is base64 of the raw 32-byte
 * Ed25519 key (see stages/03-distribution/references/info-json-and-signing-spec.md).
 *
 * Built per: docs/superpowers/plans/2026-10-10-connector-p4-distribution.md
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Verifies the Connector's own update package at `upgrader_pre_download`.
 */
class Beexy_Connector_Update_Verifier {

	/**
	 * wp-config override for the signing public key (base64 of the raw 32-byte
	 * Ed25519 public key). Lets staging point at a test key without editing the
	 * shipped constant. The real key is generated + supplied by the operator
	 * offline (host-standup-runbook.md); the private key never enters the repo.
	 */
	const PUBLIC_KEY_CONSTANT = 'BEEXY_CONNECTOR_UPDATE_PUBLIC_KEY';

	/**
	 * The embedded signing public key (base64 of the raw 32-byte Ed25519 key).
	 * Set 2026-10-11 to the updates.beexy.io channel key; the matching private key
	 * lives in the repo's gitignored _secrets/ store (never committed) + Voxxy's
	 * password manager, never on CI or the update host. An empty value fails closed
	 * (refuses every update), which is safe. A wp-config BEEXY_CONNECTOR_UPDATE_PUBLIC_KEY
	 * override wins for staging against a test key.
	 */
	const PUBLIC_KEY_B64 = 'SQPWYljXlpsoHCZuqX26UR54ldziDO/sgkryY0mjdqM=';

	/**
	 * Register pre-download verification for this plugin's update channel, plus an
	 * admin warning when this host cannot verify signatures at all.
	 *
	 * @return void
	 */
	public static function init() {
		$self = new self();
		add_filter( 'upgrader_pre_download', array( $self, 'pre_download' ), 10, 4 );
		if ( $self->needs_sodium_notice() ) {
			add_action( 'admin_notices', array( $self, 'render_sodium_notice' ) );
		}
	}

	/**
	 * Verify OUR plugin's package before it installs. Every other plugin/theme/core
	 * update passes through untouched. Returns the passed reply for anything that is
	 * not our update, a downloaded temp-file path on a good signature (and a
	 * non-downgrade version), or a WP_Error to abort cleanly otherwise.
	 *
	 * @param bool|string|\WP_Error $reply      Short-circuit reply (false = proceed).
	 * @param string                $package    The package URL (= info.json download_url).
	 * @param \WP_Upgrader|null     $upgrader   The running upgrader (unused).
	 * @param array                 $hook_extra Context; carries ['plugin'] for a plugin update.
	 * @return bool|string|\WP_Error
	 */
	public function pre_download( $reply, $package = '', $upgrader = null, $hook_extra = array() ) {
		unset( $upgrader );
		if ( ! $this->is_our_update( $hook_extra ) || ! is_string( $package ) || '' === $package ) {
			return $reply; // Not ours (or nothing to fetch): never interfere.
		}
		if ( ! $this->sodium_available() ) {
			return $this->fail(
				'sodium_missing',
				__( 'This server lacks the Sodium cryptography extension, so the Beexy Connector update signature cannot be verified. Update refused.', 'beexy-connector' )
			);
		}
		$public_key = $this->public_key_raw();
		if ( '' === $public_key ) {
			return $this->fail(
				'no_public_key',
				__( 'No Beexy Connector update signing key is configured, so the update cannot be verified. Update refused.', 'beexy-connector' )
			);
		}
		// Fetch the small signature first, so a missing/unfetchable signature fails
		// without pulling the full package.
		$signature = $this->fetch_signature( $package );
		if ( '' === $signature ) {
			return $this->fail(
				'signature_unavailable',
				__( 'The Beexy Connector update signature could not be fetched. Update refused.', 'beexy-connector' )
			);
		}
		$zip = $this->download( $package );
		if ( $this->is_error( $zip ) ) {
			return $zip; // Let WordPress surface the download failure.
		}
		if ( ! self::is_signature_valid( $this->read_file( $zip ), $signature, $public_key ) ) {
			$this->cleanup( $zip );
			return $this->fail(
				'bad_signature',
				__( 'The Beexy Connector update failed signature verification and was refused.', 'beexy-connector' )
			);
		}
		// Authenticity proven. Defence-in-depth: refuse a rollback to an older
		// version than the one running. The package version is read from the
		// signed (now verified) ZIP, so info.json's version claim is not trusted
		// here. Best-effort: when the version cannot be read, the signature alone
		// (authenticity) stands and the update proceeds.
		$package_version = $this->package_version( $zip );
		if ( null !== $package_version && version_compare( $package_version, $this->installed_version(), '<' ) ) {
			$this->cleanup( $zip );
			return $this->fail(
				'downgrade_blocked',
				__( 'The Beexy Connector update is older than the installed version and was refused.', 'beexy-connector' )
			);
		}
		return $zip; // Verified: hand WordPress the already-downloaded file.
	}

	/**
	 * Pure Ed25519 detached-signature check. No WordPress, no I/O. All inputs are
	 * raw bytes (not base64).
	 *
	 * @param string $message    The exact package (ZIP) bytes.
	 * @param string $signature  Raw 64-byte Ed25519 signature.
	 * @param string $public_key Raw 32-byte Ed25519 public key.
	 * @return bool
	 */
	public static function is_signature_valid( $message, $signature, $public_key ) {
		if ( ! is_string( $message ) || ! is_string( $signature ) || ! is_string( $public_key ) ) {
			return false;
		}
		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			return false;
		}
		if ( SODIUM_CRYPTO_SIGN_BYTES !== strlen( $signature ) || SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES !== strlen( $public_key ) ) {
			return false;
		}
		try {
			return sodium_crypto_sign_verify_detached( $signature, $message, $public_key );
		} catch ( \Exception $e ) {
			return false;
		}
	}

	/**
	 * Does this host need the "cannot verify updates" admin warning? True only when
	 * the Sodium primitive is absent (a host condition that silently pauses updates).
	 * An empty embedded key is a pre-rollout state, not an end-site warning.
	 *
	 * @return bool
	 */
	public function needs_sodium_notice() {
		return ! $this->sodium_available();
	}

	/**
	 * Admin warning shown when updates are paused because signatures cannot be
	 * verified on this host.
	 *
	 * @return void
	 */
	public function render_sodium_notice() {
		if ( ! current_user_can( 'update_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p>';
		echo esc_html__( 'Beexy Connector cannot verify the signature of its automatic updates because this server lacks the Sodium (libsodium) PHP extension. Automatic updates are paused for safety; ask your host to enable Sodium.', 'beexy-connector' );
		echo '</p></div>';
	}

	// --- I/O seams (overridden by the test doubles) ---

	/**
	 * Whether the Sodium verification primitive is available on this host.
	 *
	 * @return bool
	 */
	protected function sodium_available() {
		return function_exists( 'sodium_crypto_sign_verify_detached' ) && defined( 'SODIUM_CRYPTO_SIGN_BYTES' );
	}

	/**
	 * The raw signing public-key SOURCE string (base64): the wp-config override
	 * wins, else the embedded constant. Split from public_key_raw() so the decode +
	 * length validation can be tested without defining a constant.
	 *
	 * @return string
	 */
	protected function public_key_b64() {
		return defined( self::PUBLIC_KEY_CONSTANT ) ? (string) constant( self::PUBLIC_KEY_CONSTANT ) : self::PUBLIC_KEY_B64;
	}

	/**
	 * The raw signing public key, decoded + length-checked. Empty string when none
	 * is configured, the value is not valid base64, or it is not a 32-byte key.
	 *
	 * @return string Raw key bytes, or '' when unusable.
	 */
	protected function public_key_raw() {
		$b64 = trim( $this->public_key_b64() );
		if ( '' === $b64 ) {
			return '';
		}
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- decoding a base64 Ed25519 public key, not obfuscation.
		$raw = base64_decode( $b64, true );
		if ( ! is_string( $raw ) || SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES !== strlen( $raw ) ) {
			return '';
		}
		return $raw;
	}

	/**
	 * Download the package over HTTPS to a temp file (WordPress validates the TLS
	 * cert by default). Returns a path or a WP_Error.
	 *
	 * @param string $url Package URL.
	 * @return string|\WP_Error
	 */
	protected function download( $url ) {
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		return download_url( $url );
	}

	/**
	 * Fetch the detached signature from `<package>.sig` over HTTPS and base64-decode
	 * it to raw bytes. Follows a small number of redirects (the signature is
	 * cryptographically verified regardless of where it is served, and the front may
	 * redirect to storage). Returns '' on any failure (which fails the update closed).
	 *
	 * @param string $package Package URL.
	 * @return string Raw signature bytes, or '' when unavailable.
	 */
	protected function fetch_signature( $package ) {
		$response = wp_remote_get(
			$package . '.sig',
			array(
				'timeout'     => 10,
				'redirection' => 3,
			)
		);
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return '';
		}
		$body = trim( (string) wp_remote_retrieve_body( $response ) );
		if ( '' === $body ) {
			return '';
		}
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- decoding a base64 Ed25519 signature, not obfuscation.
		$raw = base64_decode( $body, true );
		return is_string( $raw ) ? $raw : '';
	}

	/**
	 * Read a downloaded local temp file's bytes.
	 *
	 * @param string $path Local path returned by download().
	 * @return string
	 */
	protected function read_file( $path ) {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- reading a local temp file from download_url(), not a remote fetch.
		$bytes = file_get_contents( $path );
		return is_string( $bytes ) ? $bytes : '';
	}

	/**
	 * The plugin version inside the downloaded + verified package, or null when it
	 * cannot be determined (ZipArchive unavailable, entry missing, or no Version
	 * header). Null means "skip the best-effort downgrade check".
	 *
	 * @param string $zip_path Local path to the verified package ZIP.
	 * @return string|null
	 */
	protected function package_version( $zip_path ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return null;
		}
		$zip = new ZipArchive();
		if ( true !== $zip->open( $zip_path ) ) {
			return null;
		}
		$main = $zip->getFromName( 'beexy-connector/beexy-connector.php' );
		$zip->close();
		if ( ! is_string( $main ) || '' === $main ) {
			return null;
		}
		if ( ! preg_match( '/^\s*\*\s*Version:\s*(\S+)/m', $main, $m ) ) {
			return null;
		}
		return $m[1];
	}

	/**
	 * The currently-running (installed) plugin version. During an update the
	 * pre-download hook runs in the old code's context, so this is the version the
	 * incoming package must not go below.
	 *
	 * @return string
	 */
	protected function installed_version() {
		return Beexy_Connector_Constants::VERSION;
	}

	/**
	 * Remove a downloaded temp file after a failed verification.
	 *
	 * @param string $path Local path.
	 * @return void
	 */
	protected function cleanup( $path ) {
		if ( is_string( $path ) && '' !== $path && is_file( $path ) ) {
			wp_delete_file( $path );
		}
	}

	/**
	 * Whether a value is a WP_Error.
	 *
	 * @param mixed $value Value to test.
	 * @return bool
	 */
	protected function is_error( $value ) {
		return function_exists( 'is_wp_error' ) && is_wp_error( $value );
	}

	/**
	 * Is this hook firing for THIS plugin's update?
	 *
	 * @param array $hook_extra Upgrader context.
	 * @return bool
	 */
	private function is_our_update( $hook_extra ) {
		if ( ! is_array( $hook_extra ) || empty( $hook_extra['plugin'] ) ) {
			return false;
		}
		return plugin_basename( BEEXY_CONNECTOR_PLUGIN_FILE ) === $hook_extra['plugin'];
	}

	/**
	 * Build the refusal WP_Error (and log it when WP_DEBUG is on).
	 *
	 * @param string $code    Short code suffix.
	 * @param string $message Human-readable reason.
	 * @return \WP_Error
	 */
	private function fail( $code, $message ) {
		Beexy_Connector_Logger::get_instance()->warning(
			'update-verify: refused',
			array( 'code' => $code )
		);
		return new \WP_Error( 'beexy_connector_update_' . $code, $message );
	}
}
