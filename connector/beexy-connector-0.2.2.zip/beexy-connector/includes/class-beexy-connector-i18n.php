<?php
/**
 * Text-domain loader.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Loads translations.
 */
class Beexy_Connector_I18n {

	/**
	 * Load the plugin text domain.
	 *
	 * @return void
	 */
	public static function load() {
		load_plugin_textdomain(
			Beexy_Connector_Constants::TEXT_DOMAIN,
			false,
			dirname( plugin_basename( BEEXY_CONNECTOR_PLUGIN_FILE ) ) . '/languages'
		);
	}
}
