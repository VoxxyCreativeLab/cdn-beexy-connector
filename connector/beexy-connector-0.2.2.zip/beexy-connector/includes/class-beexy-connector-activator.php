<?php
/**
 * Activation / deactivation hooks.
 *
 * The plugin is configured entirely by wp-config constants, so activation stores
 * nothing SSRF-critical. It only records the installed version for diagnostics.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Activation handler.
 */
class Beexy_Connector_Activator {

	/**
	 * On activation.
	 *
	 * @return void
	 */
	public static function activate() {
		update_option( 'beexy_connector_version', Beexy_Connector_Constants::VERSION );
		// Flag a one-time redirect to the settings page so a non-technical operator
		// lands on the one-field setup right after activating (see Admin::maybe_activation_redirect).
		set_transient( 'beexy_connector_activation_redirect', 1, 30 );
		// Daily off-hot-path license re-check (F3). The hot beacon path only ever
		// reads the cached verdict; this keeps it current (e.g. a key revoked
		// server-side is caught within a day).
		if ( ! wp_next_scheduled( Beexy_Connector_Constants::LICENSE_CRON_HOOK ) ) {
			wp_schedule_event( time(), 'daily', Beexy_Connector_Constants::LICENSE_CRON_HOOK );
		}
	}

	/**
	 * On deactivation.
	 *
	 * @return void
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( Beexy_Connector_Constants::LICENSE_CRON_HOOK );
	}
}
