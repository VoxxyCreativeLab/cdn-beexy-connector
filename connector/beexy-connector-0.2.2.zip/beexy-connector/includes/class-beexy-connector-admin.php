<?php
/**
 * Admin settings + status page — the one-paste config UI.
 *
 * The operator pastes their Beexy sGTM URL (+ an optional Pixel event path) and the
 * plugin derives everything else (see Beexy_Connector_Config). Writes go through the
 * WordPress Settings API, so the capability (manage_options) + the settings-group
 * nonce are enforced by core on options.php — there is no hand-rolled $_POST handler
 * to get wrong (the Stape CVE-2024-8712 class). Each value is validated server-side
 * by the sanitize callbacks here AND re-validated by Proxy_Config::from_source() on
 * load. All template output is escaped (CVE-2024-8712 was reflected XSS). When the
 * SSRF-critical wp-config constants are defined they WIN and lock the UI read-only
 * (the paranoid-host / migration path).
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Admin settings + status page.
 */
class Beexy_Connector_Admin {

	const OPTION_GROUP   = 'beexy_connector';
	const OPT_SGTM_URL   = 'beexy_connector_sgtm_url';
	const OPT_PIXEL_PATH = 'beexy_connector_pixel_path';

	/**
	 * Register admin hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_activation_redirect' ) );
		add_action( 'admin_post_beexy_connector_verify', array( __CLASS__, 'run_verify' ) );
	}

	/**
	 * Add the settings page under Settings.
	 *
	 * @return void
	 */
	public static function menu() {
		add_options_page(
			__( 'Beexy Connector', 'beexy-connector' ),
			__( 'Beexy Connector', 'beexy-connector' ),
			Beexy_Connector_Constants::CAPABILITY,
			Beexy_Connector_Constants::SLUG,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Register the settings (sGTM URL, Pixel path). The Settings API enforces the
	 * capability + the settings-group nonce on save (options.php); the sanitize
	 * callbacks are the server-side validation gate for each value.
	 *
	 * @return void
	 */
	public static function register() {
		register_setting(
			self::OPTION_GROUP,
			self::OPT_SGTM_URL,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( __CLASS__, 'sanitize_sgtm_url' ),
				'default'           => '',
			)
		);
		register_setting(
			self::OPTION_GROUP,
			self::OPT_PIXEL_PATH,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( __CLASS__, 'sanitize_pixel_path' ),
				'default'           => '',
			)
		);
		register_setting(
			self::OPTION_GROUP,
			Beexy_Connector_License::OPT_KEY,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( __CLASS__, 'sanitize_license_key' ),
				'default'           => '',
			)
		);
		register_setting(
			self::OPTION_GROUP,
			Beexy_Connector_License::OPT_MODE,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( __CLASS__, 'sanitize_license_mode' ),
				'default'           => Beexy_Connector_Constants::LICENSE_MODE_WATCH,
			)
		);
	}

	/**
	 * True when the SSRF-critical wp-config constants lock the config (UI read-only).
	 *
	 * @return bool
	 */
	public static function is_locked() {
		foreach ( Beexy_Connector_Constants::$critical_constants as $const ) {
			if ( defined( $const ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Sanitize the pasted sGTM URL: an absolute https URL with a host, or empty
	 * (empty disables the proxy). A non-https / hostless value is rejected with a
	 * settings error and the previous value is kept (a typo never silently wipes a
	 * working config). from_source() re-validates on load regardless of this.
	 *
	 * @param mixed $raw Raw option value.
	 * @return string
	 */
	public static function sanitize_sgtm_url( $raw ) {
		$url = esc_url_raw( trim( (string) $raw ) );
		if ( '' === $url ) {
			return '';
		}
		$scheme = strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) );
		$host   = (string) wp_parse_url( $url, PHP_URL_HOST );
		if ( 'https' !== $scheme || '' === $host ) {
			add_settings_error(
				self::OPT_SGTM_URL,
				'invalid_sgtm_url',
				__( 'The Beexy sGTM URL must be a full https:// address, e.g. https://sst.yoursite.com/your-random-path.', 'beexy-connector' )
			);
			return (string) get_option( self::OPT_SGTM_URL, '' );
		}
		return $url;
	}

	/**
	 * Sanitize the optional Pixel event path: leading-slash, no trailing slash,
	 * restricted to unreserved path characters. Empty is allowed (no Pixel path).
	 *
	 * @param mixed $raw Raw option value.
	 * @return string
	 */
	public static function sanitize_pixel_path( $raw ) {
		$path = trim( (string) $raw );
		if ( '' === $path ) {
			return '';
		}
		$path = '/' . trim( $path, '/' );
		if ( '/' === $path || preg_match( '#[^A-Za-z0-9/_-]#', $path ) ) {
			add_settings_error(
				self::OPT_PIXEL_PATH,
				'invalid_pixel_path',
				__( 'The Pixel event path must start with / and use only letters, numbers, dashes, underscores and slashes.', 'beexy-connector' )
			);
			return (string) get_option( self::OPT_PIXEL_PATH, '' ); // Keep the previous value on a bad edit.
		}
		return $path;
	}

	/**
	 * Sanitize the license key: empty (clears it), or a well-formed opaque key
	 * (bx_live_ / bx_test_ + 43 url-safe chars, matching the 0017 Gate input check).
	 * A malformed value is rejected with a settings error and the previous value is
	 * kept (a typo never silently wipes a working key). The Gate re-validates it.
	 *
	 * @param mixed $raw Raw option value.
	 * @return string
	 */
	public static function sanitize_license_key( $raw ) {
		$key = trim( (string) $raw );
		if ( '' === $key ) {
			return '';
		}
		if ( ! preg_match( '/^bx_(live|test)_[A-Za-z0-9_-]{43}$/', $key ) ) {
			add_settings_error(
				Beexy_Connector_License::OPT_KEY,
				'invalid_license_key',
				__( 'That Beexy license key looks malformed (it should start with bx_live_ or bx_test_). The previous value was kept.', 'beexy-connector' )
			);
			return (string) get_option( Beexy_Connector_License::OPT_KEY, '' );
		}
		return $key;
	}

	/**
	 * Sanitize the license mode to one of Off / Watch / Block. Anything else falls
	 * back to Watch (observe, never block) so a bad value can never start enforcing.
	 *
	 * @param mixed $raw Raw option value.
	 * @return string
	 */
	public static function sanitize_license_mode( $raw ) {
		$mode    = is_string( $raw ) ? strtolower( trim( $raw ) ) : '';
		$allowed = array(
			Beexy_Connector_Constants::LICENSE_MODE_OFF,
			Beexy_Connector_Constants::LICENSE_MODE_WATCH,
			Beexy_Connector_Constants::LICENSE_MODE_BLOCK,
		);
		return in_array( $mode, $allowed, true ) ? $mode : Beexy_Connector_Constants::LICENSE_MODE_WATCH;
	}

	/**
	 * Render the settings + status page.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( Beexy_Connector_Constants::CAPABILITY ) ) {
			return;
		}

		$config = Beexy_Connector_Config::load();

		// Refresh the license verdict on admin load, OFF the hot beacon path, so the
		// settings page shows a current result; the daily cron covers the background.
		$beexy_license = Beexy_Connector_License::get_instance();
		if ( '' !== $beexy_license->key() && Beexy_Connector_Constants::LICENSE_MODE_OFF !== $beexy_license->mode() ) {
			$beexy_license->refresh();
		}

		$template = dirname( BEEXY_CONNECTOR_PLUGIN_FILE ) . '/templates/admin-status.php';
		if ( is_file( $template ) ) {
			include $template;
		}
	}

	/**
	 * One-time redirect to the settings page right after activation, so a
	 * non-technical operator lands on the one-field setup instead of hunting for it.
	 * Skipped on bulk activation.
	 *
	 * @return void
	 */
	public static function maybe_activation_redirect() {
		if ( ! get_transient( 'beexy_connector_activation_redirect' ) ) {
			return;
		}
		delete_transient( 'beexy_connector_activation_redirect' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only bulk-activation guard, no state change.
		if ( isset( $_GET['activate-multi'] ) || ! current_user_can( Beexy_Connector_Constants::CAPABILITY ) ) {
			return;
		}
		wp_safe_redirect( admin_url( 'options-general.php?page=' . Beexy_Connector_Constants::SLUG ) );
		exit;
	}

	/**
	 * Handle the "Verify connection" action: server-side GET to the configured
	 * upstream loader endpoint (a validated https host, short timeout, no redirects),
	 * evaluate the verdict, stash it in a transient, and return to the settings page.
	 *
	 * @return void
	 */
	public static function run_verify() {
		if ( ! current_user_can( Beexy_Connector_Constants::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'beexy-connector' ) );
		}
		check_admin_referer( 'beexy_connector_verify' );

		$result = array(
			'reachable' => false,
			'bx_cookie' => false,
			'message'   => __( 'Not configured yet — save your Beexy sGTM URL first.', 'beexy-connector' ),
		);

		$config = Beexy_Connector_Config::load();
		if ( $config instanceof Beexy_Connector_Proxy_Config ) {
			$paths    = $config->proxy_paths();
			$endpoint = $config->upstream_base() . ( isset( $paths[0] ) ? $paths[0] : '' );

			// Same SSRF guard as the proxy hot path: refuse to probe unless the
			// upstream host resolves to a PUBLIC IP. WordPress's own
			// wp_http_validate_url() misses link-local/metadata (169.254/16), IPv6,
			// and the IPv4-in-IPv6 / NAT64 forms this plugin hardened against, so this
			// admin-triggered fetch must not become an internal-https SSRF oracle.
			// (A manual probe cannot pin the IP into wp_remote_get, so a DNS-rebinding
			// window remains — acceptable for a one-off authenticated admin action;
			// the hot path pins via CURLOPT_RESOLVE.)
			try {
				$guard = new Beexy_Connector_Ssrf_Guard( new Beexy_Connector_System_Dns_Resolver() );
				$guard->resolve_and_pin( $config );
			} catch ( Beexy_Connector_Http_Exception $e ) {
				$result['message'] = __( 'Upstream host does not resolve to a public address — refusing to probe it.', 'beexy-connector' );
				set_transient( 'beexy_connector_verify_result', $result, 300 );
				wp_safe_redirect( admin_url( 'options-general.php?page=' . Beexy_Connector_Constants::SLUG ) );
				exit;
			}

			$response = wp_remote_get(
				$endpoint,
				array(
					'timeout'     => 5,
					'redirection' => 0,
					'sslverify'   => true,
					'headers'     => array( 'Accept' => '*/*' ),
				)
			);

			if ( is_wp_error( $response ) ) {
				$result['message'] = $response->get_error_message();
			} else {
				$status  = (int) wp_remote_retrieve_response_code( $response );
				$cookies = wp_remote_retrieve_header( $response, 'set-cookie' );
				$lines   = is_array( $cookies ) ? $cookies : ( '' !== (string) $cookies ? array( (string) $cookies ) : array() );
				$verdict = self::evaluate_probe( $status, $lines );

				$result['reachable'] = $verdict['reachable'];
				$result['bx_cookie'] = $verdict['bx_cookie'];
				if ( ! $verdict['reachable'] ) {
					/* translators: %d: HTTP status code returned by the upstream. */
					$result['message'] = sprintf( __( 'Upstream returned HTTP %d.', 'beexy-connector' ), $status );
				} elseif ( $verdict['bx_cookie'] ) {
					$result['message'] = __( 'Connected — upstream reachable and issuing Beexy cookies.', 'beexy-connector' );
				} else {
					$result['message'] = __( 'Upstream reachable. Beexy _bx_ cookies are set only for consented visitors (by Beexy Identity + Consent), so they are not visible to this server-side check — confirm cookie durability in a browser.', 'beexy-connector' );
				}
			}
		}

		set_transient( 'beexy_connector_verify_result', $result, 300 );
		wp_safe_redirect( admin_url( 'options-general.php?page=' . Beexy_Connector_Constants::SLUG ) );
		exit;
	}

	/**
	 * Evaluate a verification probe of the upstream loader endpoint.
	 *
	 * Pure: reachable when the status is a non-error (2xx/3xx); bx_cookie when any
	 * Set-Cookie line carries a Beexy `_bx_*` cookie name.
	 *
	 * @param int      $status           Upstream HTTP status.
	 * @param string[] $set_cookie_lines Set-Cookie header lines from the response.
	 * @return array{reachable:bool,bx_cookie:bool}
	 */
	public static function evaluate_probe( $status, array $set_cookie_lines ) {
		$reachable = ( (int) $status >= 200 && (int) $status < 400 );
		$bx_cookie = false;
		foreach ( $set_cookie_lines as $line ) {
			if ( preg_match( '/(^|[;\s])_bx_[A-Za-z0-9_]+=/', (string) $line ) ) {
				$bx_cookie = true;
				break;
			}
		}
		return array(
			'reachable' => $reachable,
			'bx_cookie' => $bx_cookie,
		);
	}

	/**
	 * Map a probe verdict to a WordPress notice severity.
	 *
	 * A reachable upstream is NEVER a warning. The Beexy `_bx_*` cookies are
	 * consent-gated and set by Beexy Identity + Consent for real, consented
	 * browsers, so they are invisible to this anonymous server-side probe — their
	 * absence here is expected, not a fault (BACKLOG #11). Only an unreachable
	 * upstream is an error; a reachable one is 'success' (cookie seen) or the
	 * neutral 'info' (cookie not observable from the server).
	 *
	 * @param bool $reachable Whether the upstream returned a non-error status.
	 * @param bool $bx_cookie Whether a Beexy `_bx_*` Set-Cookie was observed.
	 * @return string One of 'success', 'info', or 'error' — never 'warning'.
	 */
	public static function probe_severity( $reachable, $bx_cookie ) {
		if ( ! $reachable ) {
			return 'error';
		}
		return $bx_cookie ? 'success' : 'info';
	}

	/**
	 * The endpoints an operator points their Beexy setup at to activate same-origin
	 * durability, derived from the claimed proxy paths (the set the proxy actually
	 * forwards — so the panel can never contradict it):
	 *   - 'loader': the first claimed path (the sGTM loader path), or '' if none.
	 *   - 'pixel' : the second claimed path (the optional Beexy Pixel path), or ''.
	 *
	 * @param string[] $proxy_paths The configured claimed path prefixes, in order.
	 * @return array{loader:string,pixel:string} Loader + optional Pixel targets.
	 */
	public static function activation_targets( array $proxy_paths ) {
		return array(
			'loader' => isset( $proxy_paths[0] ) ? (string) $proxy_paths[0] : '',
			'pixel'  => isset( $proxy_paths[1] ) ? (string) $proxy_paths[1] : '',
		);
	}
}
