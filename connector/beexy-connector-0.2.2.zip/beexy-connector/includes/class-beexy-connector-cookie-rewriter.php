<?php
/**
 * Rewrites the Domain attribute of Set-Cookie response headers.
 *
 * Pure: no WordPress, no I/O. The load-bearing behaviour of the whole product —
 * it makes the Beexy `_bx_*` cookies first-party (contract C-COOKIE-2..5):
 *
 *  - rewrites ONLY the Domain attribute to the configured eTLD+1,
 *  - preserves Secure / HttpOnly / SameSite / Path / Max-Age / Expires,
 *  - leaves host-only cookies (no Domain) host-only,
 *  - never touches the cookie name/value bytes (base64url byte-stability, DR-24),
 *  - never collapses multiple Set-Cookie lines (each is processed individually).
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Set-Cookie Domain rewriter.
 */
class Beexy_Connector_Cookie_Rewriter {

	/**
	 * Rewrite the Domain attribute on every Set-Cookie line.
	 *
	 * Non-Set-Cookie lines are dropped from the result (the caller sources them
	 * separately via Beexy_Connector_Header_Filter).
	 *
	 * @param string[]                       $header_lines Raw response header lines.
	 * @param Beexy_Connector_Proxy_Config   $config       Validated config (supplies the target Domain).
	 * @return string[] Rewritten Set-Cookie lines, one per cookie.
	 */
	public function rewrite( array $header_lines, Beexy_Connector_Proxy_Config $config ) {
		$domain = $config->cookie_domain();
		$out    = array();

		foreach ( $header_lines as $line ) {
			$line = (string) $line;
			if ( 0 !== stripos( $line, 'Set-Cookie:' ) ) {
				continue;
			}

			// Rewrite the Domain attribute to the configured value, tolerating optional
			// whitespace around the `=` (`Domain =value`). A malformed cookie may carry
			// more than one Domain: the FIRST is rewritten and any further Domain is
			// dropped, collapsing to a single canonical attribute (emitting a duplicate
			// Domain risks a strict WAF/CDN rejecting the cookie, losing durability). A
			// callback avoids any $-backreference interpretation and guarantees the
			// cookie value bytes are untouched; the leading `;` anchor keeps the match
			// on attribute boundaries only, never inside the cookie value.
			$seen      = false;
			$rewritten = preg_replace_callback(
				'/;[ \t]*Domain[ \t]*=[^;]*/i',
				static function () use ( $domain, &$seen ) {
					if ( $seen ) {
						return ''; // Drop any further Domain attribute (dedupe).
					}
					$seen = true;
					return '; Domain=' . $domain;
				},
				$line
			);

			$out[] = ( null === $rewritten ) ? $line : $rewritten;
		}

		return $out;
	}
}
