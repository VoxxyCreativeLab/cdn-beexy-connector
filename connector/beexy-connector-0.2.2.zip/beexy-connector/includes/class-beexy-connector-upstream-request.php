<?php
/**
 * Outbound upstream request (value object).
 *
 * Pure: the fully-built, already-validated request handed to the HTTP client.
 * The client MUST NOT re-derive the host — the target URL and the pinned
 * resolve entry are fixed here by the SSRF guard + request builder.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Immutable upstream request.
 */
class Beexy_Connector_Upstream_Request {

	/** @var string */
	private $method;
	/** @var string */
	private $url;
	/** @var string[] */
	private $headers;
	/** @var string|null */
	private $body;
	/** @var array{host:string,port:int,ip:string} */
	private $resolve_pin;
	/** @var int */
	private $connect_timeout_ms;
	/** @var int */
	private $total_timeout_ms;
	/** @var int */
	private $max_bytes;

	/**
	 * @param string      $method             HTTP method.
	 * @param string      $url                Absolute URL, built from the allowlisted base only.
	 * @param string[]    $headers            Request header lines ("Name: value").
	 * @param string|null $body               Raw body, or null.
	 * @param array       $resolve_pin        DNS pin: host, port, ip.
	 * @param int         $connect_timeout_ms Connect timeout in ms.
	 * @param int         $total_timeout_ms   Total timeout in ms.
	 * @param int         $max_bytes          Response size cap in bytes.
	 */
	public function __construct( $method, $url, array $headers, $body, array $resolve_pin, $connect_timeout_ms, $total_timeout_ms, $max_bytes ) {
		$this->method             = (string) $method;
		$this->url                = (string) $url;
		$this->headers            = $headers;
		$this->body               = ( null === $body ) ? null : (string) $body;
		$this->resolve_pin        = $resolve_pin;
		$this->connect_timeout_ms = (int) $connect_timeout_ms;
		$this->total_timeout_ms   = (int) $total_timeout_ms;
		$this->max_bytes          = (int) $max_bytes;
	}

	/** @return string */
	public function method() {
		return $this->method;
	}
	/** @return string */
	public function url() {
		return $this->url;
	}
	/** @return string[] */
	public function headers() {
		return $this->headers;
	}
	/** @return string|null */
	public function body() {
		return $this->body;
	}
	/** @return array{host:string,port:int,ip:string} */
	public function resolve_pin() {
		return $this->resolve_pin;
	}
	/** @return int */
	public function connect_timeout_ms() {
		return $this->connect_timeout_ms;
	}
	/** @return int */
	public function total_timeout_ms() {
		return $this->total_timeout_ms;
	}
	/** @return int */
	public function max_bytes() {
		return $this->max_bytes;
	}
}
