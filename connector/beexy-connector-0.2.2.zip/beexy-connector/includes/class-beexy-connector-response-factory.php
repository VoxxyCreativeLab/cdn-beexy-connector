<?php
/**
 * Builds fail-open responses (contract C-FAIL-1, C-FAIL-2).
 *
 * Pure: no WordPress, no I/O. A GET (pixel/beacon) fails open to a 1x1
 * transparent GIF; any other method fails open to 204 No Content. Both carry the
 * canonical Beexy_Connector_Header_Filter::FORCED_HEADERS (Cache-Control: no-store
 * + X-Content-Type-Options: nosniff) and never block the page.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Fail-open response factory.
 */
class Beexy_Connector_Response_Factory {

	/**
	 * Base64 of the canonical 43-byte 1x1 transparent GIF.
	 */
	const GIF_1X1_BASE64 = 'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';

	/**
	 * Build a fail-open response for a request.
	 *
	 * @param Beexy_Connector_Proxy_Request $req Inbound request.
	 * @return Beexy_Connector_Proxy_Response
	 */
	public function fail_open( Beexy_Connector_Proxy_Request $req ) {
		if ( 'GET' === $req->method() ) {
			// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- decoding a hardcoded 1x1 GIF constant, not obfuscation.
			$body = (string) base64_decode( self::GIF_1X1_BASE64 );
			return new Beexy_Connector_Proxy_Response(
				200,
				array_merge(
					array(
						'Content-Type: image/gif',
						'Content-Length: ' . strlen( $body ),
					),
					Beexy_Connector_Header_Filter::FORCED_HEADERS
				),
				$body
			);
		}

		return new Beexy_Connector_Proxy_Response(
			204,
			Beexy_Connector_Header_Filter::FORCED_HEADERS,
			''
		);
	}
}
