<?php
/**
 * Inbound proxy request (value object).
 *
 * Pure: no WordPress, no superglobals. Built by the WP edge
 * (Beexy_Connector_Request_Reader) from $_SERVER / getallheaders() / php://input,
 * then consumed by the pure core. The core never touches a superglobal.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Immutable inbound request.
 */
class Beexy_Connector_Proxy_Request {

	/** @var string */
	private $method;
	/** @var string */
	private $path;
	/** @var string */
	private $query;
	/** @var array<string,string> */
	private $headers;
	/** @var string|null */
	private $body;
	/** @var string */
	private $remote_addr;

	/**
	 * @param string               $method      HTTP method.
	 * @param string               $path        Full request path (includes the proxy-path prefix).
	 * @param string               $query       Query string, without a leading '?'.
	 * @param array<string,string> $headers     Request headers, name => value.
	 * @param string|null          $body        Raw request body, or null.
	 * @param string               $remote_addr Trusted client IP (REMOTE_ADDR).
	 */
	public function __construct( $method, $path, $query, array $headers, $body, $remote_addr ) {
		$this->method      = strtoupper( (string) $method );
		$this->path        = (string) $path;
		$this->query       = (string) $query;
		$this->headers     = $headers;
		$this->body        = ( null === $body ) ? null : (string) $body;
		$this->remote_addr = (string) $remote_addr;
	}

	/** @return string */
	public function method() {
		return $this->method;
	}
	/** @return string */
	public function path() {
		return $this->path;
	}
	/** @return string */
	public function query() {
		return $this->query;
	}
	/** @return array<string,string> */
	public function headers() {
		return $this->headers;
	}
	/** @return string|null */
	public function body() {
		return $this->body;
	}
	/** @return string */
	public function remote_addr() {
		return $this->remote_addr;
	}
}
