<?php
/**
 * Validated proxy configuration (value object).
 *
 * Pure: no WordPress, no I/O. `from_source()` is the validation gate that
 * upholds contract C-CFG-1..5 — a malformed config throws and the plugin never
 * becomes an open proxy. The SSRF-critical invariants (https-only upstream,
 * host on the allowlist, cookie_domain == eTLD+1 of the serving host, redirects
 * disabled) live here so every code path downstream can trust the object.
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Immutable, validated proxy configuration.
 */
class Beexy_Connector_Proxy_Config {

	/** @var string */
	private $serving_host;
	/** @var string[] */
	private $proxy_paths;
	/** @var string */
	private $upstream_base;
	/** @var string */
	private $upstream_host;
	/** @var int */
	private $upstream_port;
	/** @var string[] */
	private $allowlist;
	/** @var string */
	private $cookie_domain;
	/** @var string[] */
	private $allowed_methods;
	/** @var int */
	private $connect_timeout_ms;
	/** @var int */
	private $total_timeout_ms;
	/** @var int */
	private $max_bytes;

	/**
	 * Private: build only via from_source() so the object is always validated.
	 *
	 * @param array $fields Validated fields.
	 */
	private function __construct( array $fields ) {
		foreach ( $fields as $key => $value ) {
			$this->$key = $value;
		}
	}

	/**
	 * Validate raw config and build the value object, or throw.
	 *
	 * @param array                                 $raw Raw config map.
	 * @param Beexy_Connector_Public_Suffix_List    $psl Public suffix list for eTLD+1 validation.
	 * @return self
	 * @throws Beexy_Connector_Config_Exception On any invalid field.
	 */
	public static function from_source( array $raw, Beexy_Connector_Public_Suffix_List $psl ) {
		// --- upstream base: absolute https URL with a host (C-CFG-2). ---
		$base = isset( $raw['upstream_base'] ) ? (string) $raw['upstream_base'] : '';
		// Native parse_url() is required: this class is the pure, WordPress-free
		// core and wp_parse_url() is unavailable here.
		$parts = parse_url( $base ); // phpcs:ignore WordPress.WP.AlternativeFunctions.parse_url_parse_url
		if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			throw new Beexy_Connector_Config_Exception( 'upstream_base must be an absolute URL with a host' );
		}
		if ( 'https' !== strtolower( $parts['scheme'] ) ) {
			throw new Beexy_Connector_Config_Exception( 'upstream_base must use https' );
		}
		$upstream_host = strtolower( $parts['host'] );
		$upstream_port = isset( $parts['port'] ) ? (int) $parts['port'] : 443;
		$upstream_base = 'https://' . $upstream_host . ( 443 === $upstream_port ? '' : ':' . $upstream_port );

		// --- egress allowlist: non-empty, must contain the upstream host (C-CFG-3). ---
		$allowlist = array();
		if ( isset( $raw['upstream_allowlist'] ) && is_array( $raw['upstream_allowlist'] ) ) {
			foreach ( $raw['upstream_allowlist'] as $host ) {
				$host = strtolower( trim( (string) $host ) );
				if ( '' !== $host ) {
					$allowlist[ $host ] = true;
				}
			}
		}
		$allowlist = array_keys( $allowlist );
		if ( empty( $allowlist ) || ! in_array( $upstream_host, $allowlist, true ) ) {
			throw new Beexy_Connector_Config_Exception( 'upstream host is not in the egress allowlist' );
		}

		// --- serving host + cookie_domain == eTLD+1 of the serving host (C-CFG-4). ---
		$serving_host = isset( $raw['serving_host'] )
			? strtolower( trim( (string) $raw['serving_host'], " \t\n\r\0\x0B." ) )
			: '';
		if ( '' === $serving_host ) {
			throw new Beexy_Connector_Config_Exception( 'serving_host is required' );
		}
		$registrable = $psl->registrable_domain( $serving_host );
		if ( null === $registrable ) {
			throw new Beexy_Connector_Config_Exception( 'serving_host has no registrable domain' );
		}
		// A self-referential upstream (upstream host == serving host) would forward
		// the proxy back onto its own first-party path and loop; reject it.
		if ( $upstream_host === $serving_host ) {
			throw new Beexy_Connector_Config_Exception( 'upstream host must differ from the serving host (self-reference loop)' );
		}
		// cookie_domain is OPTIONAL: when absent, adopt the eTLD+1 computed above
		// (auto-derivation). When supplied it MUST still equal that eTLD+1 — C-CFG-4
		// is unchanged; derivation never weakens the check, only absence triggers it.
		$cookie_core = strtolower( ltrim( trim( isset( $raw['cookie_domain'] ) ? (string) $raw['cookie_domain'] : '' ), '.' ) );
		if ( '' !== $cookie_core && $cookie_core !== $registrable ) {
			throw new Beexy_Connector_Config_Exception( 'cookie_domain must be the registrable domain (eTLD+1) of the serving host' );
		}
		$cookie_domain = '.' . $registrable;

		// --- proxy path(s): >=1 claimed first-party path, each absolute + non-root
		// (C-CFG-5, C-INT-1). Accept `proxy_paths` (a set — e.g. the Webloader loader
		// path + the Pixel event path, both fronted on the same upstream host) or a
		// single `proxy_path` (back-compat). Each forwards path-preserved (C-INT-2). ---
		$raw_paths = array();
		if ( isset( $raw['proxy_paths'] ) && is_array( $raw['proxy_paths'] ) ) {
			$raw_paths = $raw['proxy_paths'];
		} elseif ( isset( $raw['proxy_path'] ) ) {
			$raw_paths = array( $raw['proxy_path'] );
		}
		$proxy_paths = array();
		foreach ( $raw_paths as $candidate ) {
			$candidate = (string) $candidate;
			if ( '' === $candidate || '/' !== $candidate[0] ) {
				throw new Beexy_Connector_Config_Exception( 'proxy_path must begin with a slash' );
			}
			$candidate = '/' . trim( $candidate, '/' );
			if ( '/' === $candidate ) {
				throw new Beexy_Connector_Config_Exception( 'proxy_path must not be the site root' );
			}
			$proxy_paths[ $candidate ] = true;
		}
		$proxy_paths = array_keys( $proxy_paths );
		if ( empty( $proxy_paths ) ) {
			throw new Beexy_Connector_Config_Exception( 'at least one proxy_path is required' );
		}

		// --- redirects disabled (C-CFG-5, DNS-rebinding / open-redirect defence). ---
		$max_redirects = isset( $raw['max_redirects'] ) ? (int) $raw['max_redirects'] : 0;
		if ( 0 !== $max_redirects ) {
			throw new Beexy_Connector_Config_Exception( 'max_redirects must be 0 (redirect following is disabled)' );
		}

		// --- methods (default GET/POST), timeouts, size cap (C-CFG-5). ---
		$allowed_methods = array();
		if ( isset( $raw['allowed_methods'] ) && is_array( $raw['allowed_methods'] ) ) {
			foreach ( $raw['allowed_methods'] as $method ) {
				$method = strtoupper( trim( (string) $method ) );
				if ( '' !== $method ) {
					$allowed_methods[ $method ] = true;
				}
			}
		}
		$allowed_methods = array_keys( $allowed_methods );
		if ( empty( $allowed_methods ) ) {
			$allowed_methods = array( 'GET', 'POST' );
		}

		$connect_timeout_ms = isset( $raw['connect_timeout_ms'] ) ? (int) $raw['connect_timeout_ms'] : 1000;
		$total_timeout_ms   = isset( $raw['total_timeout_ms'] ) ? (int) $raw['total_timeout_ms'] : 2000;
		if ( $connect_timeout_ms <= 0 || $total_timeout_ms <= 0 ) {
			throw new Beexy_Connector_Config_Exception( 'timeouts must be positive' );
		}

		$max_bytes = isset( $raw['max_bytes'] ) ? (int) $raw['max_bytes'] : 262144;
		if ( $max_bytes <= 0 ) {
			throw new Beexy_Connector_Config_Exception( 'max_bytes must be positive' );
		}

		return new self(
			array(
				'serving_host'       => $serving_host,
				'proxy_paths'        => $proxy_paths,
				'upstream_base'      => $upstream_base,
				'upstream_host'      => $upstream_host,
				'upstream_port'      => $upstream_port,
				'allowlist'          => $allowlist,
				'cookie_domain'      => $cookie_domain,
				'allowed_methods'    => $allowed_methods,
				'connect_timeout_ms' => $connect_timeout_ms,
				'total_timeout_ms'   => $total_timeout_ms,
				'max_bytes'          => $max_bytes,
			)
		);
	}

	/** @return string */
	public function serving_host() {
		return $this->serving_host;
	}
	/** @return string The first claimed path (back-compat / display). */
	public function proxy_path() {
		return $this->proxy_paths[0];
	}
	/** @return string[] All claimed first-party paths (each forwarded path-preserved). */
	public function proxy_paths() {
		return $this->proxy_paths;
	}
	/** @return string */
	public function upstream_base() {
		return $this->upstream_base;
	}
	/** @return string */
	public function upstream_host() {
		return $this->upstream_host;
	}
	/** @return int */
	public function upstream_port() {
		return $this->upstream_port;
	}
	/** @return string */
	public function cookie_domain() {
		return $this->cookie_domain;
	}
	/** @return string[] */
	public function allowed_methods() {
		return $this->allowed_methods;
	}
	/** @return int */
	public function connect_timeout_ms() {
		return $this->connect_timeout_ms;
	}
	/** @return int */
	public function total_timeout_ms() {
		return $this->total_timeout_ms;
	}
	/** @return int */
	public function max_bytes() {
		return $this->max_bytes;
	}

	/**
	 * Is a host on the egress allowlist?
	 *
	 * @param string $host Host to check.
	 * @return bool
	 */
	public function is_host_allowed( $host ) {
		return in_array( strtolower( (string) $host ), $this->allowlist, true );
	}

	/**
	 * Is an (already upper-cased) HTTP method allowed?
	 *
	 * @param string $method HTTP method.
	 * @return bool
	 */
	public function is_method_allowed( $method ) {
		return in_array( strtoupper( (string) $method ), $this->allowed_methods, true );
	}

	/**
	 * Does a request path belong to ANY claimed proxy path? A bare string-prefix is
	 * NOT enough — the match must be a claimed path exactly, or that path followed
	 * by `/`, so `/collect` never captures a sibling route like `/collections`.
	 *
	 * @param string $request_path Request path (no query string).
	 * @return bool
	 */
	public function path_matches( $request_path ) {
		$request_path = (string) $request_path;
		foreach ( $this->proxy_paths as $path ) {
			if ( $request_path === $path
				|| 0 === strncmp( $request_path, $path . '/', strlen( $path ) + 1 ) ) {
				return true;
			}
		}
		return false;
	}
}
