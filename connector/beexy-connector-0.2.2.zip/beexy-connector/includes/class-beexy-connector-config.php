<?php
/**
 * Config loader — constant-or-derived.
 *
 * Each SSRF-critical value resolves CONSTANT-FIRST (an operator wp-config constant
 * wins and locks the value — the paranoid-host / migration path), else it is
 * derived from the single pasted sGTM URL option (+ optional Pixel event path) and
 * the site's own home_url(). The security gate is Proxy_Config::from_source(): a
 * value being web-editable is safe because the gate re-validates it (https-only,
 * host on the egress allowlist, cookie_domain == eTLD+1 of the serving host) and
 * the runtime SSRF guard refuses any non-public target regardless of where the
 * value came from. serving_host is derived from home_url() (a stored server-side
 * value), NEVER from the request Host header (HTTP_HOST is attacker-controlled).
 * Non-critical operational values (timeouts, size cap, method allowlist) use the
 * house filter -> option -> default ladder. Produces a validated
 * Beexy_Connector_Proxy_Config, or null when unconfigured / invalid (the caller
 * then declines to intercept / fails open).
 *
 * @package Beexy_Connector
 */

defined( 'ABSPATH' ) || exit;

/**
 * Builds the validated proxy config from constants.
 */
class Beexy_Connector_Config {

	/**
	 * Load and validate the proxy config, or null when unconfigured / invalid.
	 *
	 * @return Beexy_Connector_Proxy_Config|null
	 */
	public static function load() {
		// The ENTIRE resolution is wrapped: a throwing config filter (a third-party
		// plugin hooking beexy_connector_config_*), a corrupt vendored PSL file, or a
		// malformed stored value must never fatal the beacon path — any error
		// declines (→ the caller fails open).
		try {
			$raw = self::build_raw();
			if ( null === $raw ) {
				return null;
			}
			$psl = new Beexy_Connector_Public_Suffix_List( Beexy_Connector_Psl_Loader::rules() );
			return Beexy_Connector_Proxy_Config::from_source( $raw, $psl );
		} catch ( Beexy_Connector_Config_Exception $e ) {
			Beexy_Connector_Logger::get_instance()->warning(
				'invalid proxy configuration',
				array( 'error' => $e->getMessage() )
			);
			return null;
		} catch ( Throwable $e ) {
			Beexy_Connector_Logger::get_instance()->warning(
				'proxy configuration error',
				array( 'error' => $e->getMessage() )
			);
			return null;
		}
	}

	/**
	 * Resolve the raw config map for from_source().
	 *
	 * Each SSRF-critical value resolves CONSTANT-FIRST (an operator wp-config
	 * constant wins and locks the value), else it is derived from the single pasted
	 * sGTM URL option + the site's own home_url():
	 *
	 *  - upstream base + egress allowlist  <- BEEXY_CONNECTOR_UPSTREAM_BASE / _ALLOWLIST, else the sGTM URL host
	 *  - claimed proxy path(s)             <- BEEXY_CONNECTOR_PROXY_PATH, else the sGTM URL path (+ optional Pixel path option)
	 *  - serving host                      <- BEEXY_CONNECTOR_SERVING_HOST, else home_url() host (NEVER the request Host header)
	 *  - cookie domain                     <- BEEXY_CONNECTOR_COOKIE_DOMAIN, else derived by from_source() as the serving host's eTLD+1
	 *
	 * The security gate is from_source(); this method only chooses WHERE each value
	 * comes from, never what is valid.
	 *
	 * @return array<string,mixed>|null Raw config, or null when unconfigured.
	 */
	private static function build_raw() {
		// --- upstream: the sGTM URL (a constant base wins over the pasted-URL option). ---
		$sgtm_url = self::critical( 'upstream_base' );
		if ( null === $sgtm_url || '' === $sgtm_url ) {
			$sgtm_url = self::option( 'sgtm_url', '' );
		}
		if ( ! is_string( $sgtm_url ) || '' === trim( $sgtm_url ) ) {
			return null; // No upstream configured -> do not intercept.
		}
		$sgtm_url = trim( $sgtm_url );
		$host     = wp_parse_url( $sgtm_url, PHP_URL_HOST );
		$url_path = wp_parse_url( $sgtm_url, PHP_URL_PATH );

		// --- egress allowlist: constant wins, else the sGTM URL host. ---
		$allowlist = self::critical( 'upstream_allowlist' );
		if ( is_string( $allowlist ) ) {
			$allowlist = array_filter( array_map( 'trim', explode( ',', $allowlist ) ) );
		}
		if ( ! is_array( $allowlist ) || empty( $allowlist ) ) {
			$allowlist = $host ? array( $host ) : array();
		}

		// --- claimed path(s): the PROXY_PATH constant wins (single); else the sGTM
		// URL path (the loader endpoint) + an optional Pixel event path, both on the
		// same upstream host. Each forwards path-preserved (C-INT-2). ---
		$proxy_path_const = self::critical( 'proxy_path' );
		if ( null !== $proxy_path_const && '' !== $proxy_path_const ) {
			$proxy_paths = array( $proxy_path_const );
		} else {
			$proxy_paths = array();
			if ( is_string( $url_path ) && '' !== $url_path && '/' !== $url_path ) {
				$proxy_paths[] = $url_path;
			}
			$pixel_path = self::option( 'pixel_path', '' );
			if ( is_string( $pixel_path ) && '' !== trim( $pixel_path ) ) {
				$proxy_paths[] = trim( $pixel_path );
			}
		}

		// --- serving host: constant wins, else home_url() host. NEVER the request
		// Host header — home_url() is a stored server-side value, so deriving from it
		// is safe; HTTP_HOST is attacker-controlled and must never feed this. ---
		$serving_host = self::critical( 'serving_host' );
		if ( null === $serving_host || '' === $serving_host ) {
			$home_host    = wp_parse_url( (string) home_url(), PHP_URL_HOST );
			$serving_host = is_string( $home_host ) ? $home_host : '';
		}

		// Not enough to serve -> decline (caller fails open).
		if ( empty( $proxy_paths ) || '' === $serving_host ) {
			return null;
		}

		$raw = array(
			'serving_host'       => $serving_host,
			'proxy_paths'        => $proxy_paths,
			'upstream_base'      => $sgtm_url,
			'upstream_allowlist' => $allowlist,
			'allowed_methods'    => self::option( 'allowed_methods', array( 'GET', 'POST' ) ),
			'connect_timeout_ms' => (int) self::option( 'connect_timeout_ms', 1000 ),
			'total_timeout_ms'   => (int) self::option( 'total_timeout_ms', 2000 ),
			'max_bytes'          => (int) self::option( 'max_bytes', 262144 ),
			'max_redirects'      => 0,
		);

		// cookie_domain: the constant wins; otherwise leave it ABSENT so from_source()
		// derives it as the serving host's eTLD+1 (auto-derivation).
		$cookie_domain = self::critical( 'cookie_domain' );
		if ( null !== $cookie_domain && '' !== $cookie_domain ) {
			$raw['cookie_domain'] = $cookie_domain;
		}

		return $raw;
	}

	/**
	 * Read an SSRF-critical value from its constant ONLY.
	 *
	 * @param string $key Logical key.
	 * @return mixed|null
	 */
	private static function critical( $key ) {
		$name = isset( Beexy_Connector_Constants::$critical_constants[ $key ] )
			? Beexy_Connector_Constants::$critical_constants[ $key ]
			: '';
		return ( '' !== $name && defined( $name ) ) ? constant( $name ) : null;
	}

	/**
	 * Read a non-critical value via filter -> option -> default.
	 *
	 * @param string $key      Logical key.
	 * @param mixed  $fallback Default value when the option is unset.
	 * @return mixed
	 */
	private static function option( $key, $fallback ) {
		$value = get_option( 'beexy_connector_' . $key, null );
		if ( null === $value ) {
			$value = $fallback;
		}
		return apply_filters( 'beexy_connector_config_' . $key, $value );
	}
}
